// ChatAttic: optional ChatGPT conversation-data reader.
// Runs only after explicit user click, in the logged-in page's MAIN world.
(() => {
  window.__chatAtticTryInternal = async (mode="conversation") => {
    const imagesOnly = mode === "images-only";
    if (location.hostname !== 'chatgpt.com') return {ok:false,reason:'not-chatgpt'};
    const id = location.pathname.match(/^\/c\/([0-9a-f-]{36})(?:\/|$)/i)?.[1];
    if (!id) return {ok:false,reason:'conversation-id-unavailable'};
    try {
      const sessionResponse = await fetch('/api/auth/session', {credentials:'include'});
      if (!sessionResponse.ok) return {ok:false,reason:'session-http-'+sessionResponse.status};
      const session = await sessionResponse.json();
      const token = session?.accessToken;
      if (!token) return {ok:false,reason:'access-token-unavailable'};
      const response = await fetch('/backend-api/conversation/'+encodeURIComponent(id), {
        credentials:'include',headers:{'Authorization':'Bearer '+token,'Accept':'application/json'}
      });
      if (!response.ok) return {ok:false,reason:'conversation-http-'+response.status};
      let payload = await response.json();
      if (!payload?.mapping || !payload?.current_node) return {ok:false,reason:'conversation-tree-unavailable'};
      // A newly submitted message can appear in the UI before the conversation
      // endpoint has committed its current_node. Refresh the snapshot briefly.
      // Never merge arbitrary branches: they may be regenerated/abandoned replies.
      const getChain = data => {
        const chain=[], seen=new Set();let cursor=data.current_node;
        while(cursor && data.mapping[cursor] && !seen.has(cursor)){
          seen.add(cursor);const node=data.mapping[cursor];
          if(node.message)chain.push({id:cursor,message:node.message});
          cursor=node.parent;
        }
        return chain.reverse();
      };
      const newestTimestamp = data => {
        const chain=getChain(data);
        return Math.max(0,...chain.map(x=>Number(x.message?.create_time)||0));
      };
      let latestStamp=newestTimestamp(payload);
      // Two short retries reduce stale-end captures without slowing down image downloads.
      for(let attempt=0;attempt<2;attempt++){
        await new Promise(resolve=>setTimeout(resolve,450));
        try{
          const fresh=await fetch('/backend-api/conversation/'+encodeURIComponent(id),{
            credentials:'include',cache:'no-store',
            headers:{'Authorization':'Bearer '+token,'Accept':'application/json','Cache-Control':'no-cache'}
          });
          if(!fresh.ok)break;
          const candidate=await fresh.json();
          if(!candidate?.mapping || !candidate?.current_node)break;
          const stamp=newestTimestamp(candidate);
          if(stamp>=latestStamp){payload=candidate;latestStamp=stamp;}
        }catch(_){break;}
      }
      const nodes=getChain(payload);
      const branchNodes=Object.keys(payload.mapping).length-nodes.length;
      console.info('ChatAttic active conversation chain:',nodes.length,'nodes; outside chain:',branchNodes);
      const result=[];
      for (const {id:nodeId,message:m} of nodes) {
        const role=m?.author?.role;
        if (role!=='user' && role!=='assistant') continue;
        // The conversation mapping also contains assistant tool calls, analysis and
        // internal execution messages. Check the actual channel, not message_type:
        // message_type can be 'next' even for ordinary visible replies.
        if (role==='assistant') {
          const recipient=String(m?.recipient||m?.metadata?.recipient||'all');
          const channel=String(m?.channel||m?.metadata?.channel||m?.author?.metadata?.channel||'final');
          if (recipient!=='all' || !['final',''].includes(channel)) continue;
        }
        const parts=Array.isArray(m?.content?.parts)?m.content.parts:[];
        const text=parts.map(p=>typeof p==='string'?p:(p?.text||p?.content||'')).filter(x=>typeof x==='string').join('\n\n').trim() ||
          (typeof m?.content?.text==='string'?m.content.text:'');
        const images=[];
        const seen=new Set();
        function add(pointer,alt='') {
          if (!pointer || seen.has(pointer)) return;
          seen.add(pointer);
          // Asset pointers are references, not portable image bytes.
          images.push({src:pointer,alt:alt||'画像',error:'画像本体は未取得（内部参照のみ）',source:'conversation-metadata'});
        }
        for (const part of parts) {
          if (!part || typeof part!=='object') continue;
          const pointer=part.asset_pointer||part.image_asset_pointer||part.file_id;
          if (pointer && (/image/i.test(String(part.content_type||part.mime_type||'')) || /^(sediment|file-service):\/\//.test(String(pointer)))) add(pointer,part.name||part.filename);
        }
        const attachments=m?.metadata?.attachments;
        if (Array.isArray(attachments)) for (const a of attachments) {
          if (/^image\//.test(String(a?.mime_type||''))) add(a.id||a.file_id||a.asset_pointer,a.name);
        }
        if (!text && !images.length) continue;
        // Fallback for internal command transcripts whose channel metadata is
        // absent in some conversation payloads. Do not filter user messages.
        if (role==='assistant' && !images.length && (
          /^(?:bash -lc |python - <<|node --check |unzip -p |cat > \/|from pathlib import Path\n)/.test(text) ||
          /^\{\s*"(?:paths|path|cmd|command|tool|recipient)"\s*:/.test(text)
        )) continue;
        result.push({provider:'chatgpt',turn:result.length+1,sourceTurn:null,id:nodeId,role,text,images});
      }
      if (!result.length) return {ok:false,reason:'no-user-assistant-messages'};
      // Resolve original image file IDs through the authenticated download descriptor.
      // The descriptor's download_url is short-lived and must never be exported.
      let directSaved=0, directFailed=0;
      const imageCache=new Map();
      const extractFileId=value=>String(value||'').match(/file_[a-zA-Z0-9]+/)?.[0]||null;
      async function fetchOriginalImage(fileId){
        if(imageCache.has(fileId))return imageCache.get(fileId);
        let recovered=null;
        try{
          const descriptorResponse=await fetch('/backend-api/files/'+encodeURIComponent(fileId)+'/download',{
            credentials:'include',headers:{Authorization:'Bearer '+token,Accept:'application/json'},signal:AbortSignal.timeout(15000)
          });
          if(!descriptorResponse.ok)throw new Error('descriptor HTTP '+descriptorResponse.status);
          const descriptor=await descriptorResponse.json();
          const rawUrl=descriptor?.download_url;
          if(typeof rawUrl!=='string')throw new Error('download_url missing');
          const url=new URL(rawUrl,location.origin);
          if(url.protocol!=='https:')throw new Error('unsupported URL protocol');
          // Same-origin URLs may require session cookies. Never send credentials
          // or bearer tokens to a cross-origin download URL.
          const sameOrigin=url.origin===location.origin;
          let binaryResponse=await fetch(url.href,{
            credentials:sameOrigin?'include':'omit',
            signal:AbortSignal.timeout(30000)
          });
          // Some same-origin endpoints accept bearer auth instead of cookies.
          // Retry only for an explicit auth rejection, and ONLY on same origin.
          if(sameOrigin && (binaryResponse.status===401||binaryResponse.status===403)){
            binaryResponse=await fetch(url.href,{
              credentials:'include',
              headers:{Authorization:'Bearer '+token},
              signal:AbortSignal.timeout(30000)
            });
          }
          if(!binaryResponse.ok)throw new Error('image HTTP '+binaryResponse.status);
          const blob=await binaryResponse.blob();
          if(blob.size<16||blob.size>20*1024*1024)throw new Error('image size out of range');
          const headerMime=(blob.type||'').split(';')[0].toLowerCase();
          const bytes=new Uint8Array(await blob.slice(0,16).arrayBuffer());
          const png=bytes[0]===137&&bytes[1]===80&&bytes[2]===78&&bytes[3]===71;
          const jpg=bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
          const gif=String.fromCharCode(...bytes.slice(0,4))==='GIF8';
          const webp=String.fromCharCode(...bytes.slice(0,4))==='RIFF'&&String.fromCharCode(...bytes.slice(8,12))==='WEBP';
          const mime=png?'image/png':jpg?'image/jpeg':gif?'image/gif':webp?'image/webp':null;
          if(!mime||headerMime&&!headerMime.startsWith('image/'))throw new Error('response not recognized image');
          const dataUrl=await new Promise((resolve,reject)=>{
            const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error('FileReader error'));reader.readAsDataURL(new Blob([blob],{type:mime}));
          });
          recovered={dataUrl,source:'file-id-download'};
        }catch(e){console.warn('ChatAttic image reference not recovered',fileId.slice(-8),String(e?.message||e));}
        imageCache.set(fileId,recovered);
        return recovered;
      }
      for(const msg of result){
        if(!msg.images?.length)continue;
        const groups=new Map();
        for(const image of msg.images){
          const id=extractFileId(image.src);
          const key=id||image.src;
          if(!groups.has(key))groups.set(key,[]);
          groups.get(key).push(image);
        }
        const merged=[];
        for(const [key,group] of groups){
          const first=group[0];
          const fileId=extractFileId(first.src);
          if(!fileId){merged.push(first);continue;}
          const recovered=await fetchOriginalImage(fileId);
          if(recovered){merged.push({alt:group.find(x=>x.alt&&x.alt!=='画像')?.alt||first.alt||'画像',...recovered});directSaved++;}
          else{merged.push(first);directFailed++;}
        }
        msg.images=merged;
      }
      if(imagesOnly){
        const entries=[];
        for(const msg of result){
          let index=0;
          for(const item of msg.images||[]){
            if(typeof item.dataUrl!=='string'||!item.dataUrl.startsWith('data:image/'))continue;
            const m=item.dataUrl.match(/^data:(image\/(?:png|jpeg|gif|webp));base64,(.+)$/s);
            if(!m)continue;
            const ext={'image/png':'png','image/jpeg':'jpg','image/gif':'gif','image/webp':'webp'}[m[1]];
            const raw=atob(m[2]);const bytes=new Uint8Array(raw.length);
            for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
            const name='Turn_'+String(msg.turn).padStart(4,'0')+'_'+String(++index).padStart(2,'0')+'.'+ext;
            entries.push({name,bytes});
          }
        }
        if(!entries.length)return {ok:false,reason:'画像本体を取得できませんでした。'};
        // Minimal ZIP writer: STORE entries; original image formats are already compressed.
        const encoder=new TextEncoder(),parts=[],central=[];
        let offset=0;
        const table=new Uint32Array(256);
        for(let i=0;i<256;i++){let c=i;for(let j=0;j<8;j++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;table[i]=c>>>0;}
        function crc32(bytes){let c=0xffffffff;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;}
        function u16(d,v,o){d.setUint16(o,v,true)}function u32(d,v,o){d.setUint32(o,v>>>0,true)}
        for(const {name,bytes} of entries){
          const filename=encoder.encode(name),crc=crc32(bytes);
          const local=new Uint8Array(30+filename.length),l=new DataView(local.buffer);
          u32(l,0x04034b50,0);u16(l,20,4);u16(l,0x0800,6);u32(l,crc,14);
          u32(l,bytes.length,18);u32(l,bytes.length,22);u16(l,filename.length,26);local.set(filename,30);
          parts.push(local,bytes);
          const dir=new Uint8Array(46+filename.length),d=new DataView(dir.buffer);
          u32(d,0x02014b50,0);u16(d,20,4);u16(d,20,6);u16(d,0x0800,8);
          u32(d,crc,16);u32(d,bytes.length,20);u32(d,bytes.length,24);
          u16(d,filename.length,28);u32(d,offset,42);dir.set(filename,46);
          central.push(dir);offset+=local.length+bytes.length;
        }
        const centralLength=central.reduce((n,x)=>n+x.length,0);
        const end=new Uint8Array(22),e=new DataView(end.buffer);
        u32(e,0x06054b50,0);u16(e,entries.length,8);u16(e,entries.length,10);
        u32(e,centralLength,12);u32(e,offset,16);
        const zipBlob=new Blob([...parts,...central,end],{type:'application/zip'});
        const zipUrl=URL.createObjectURL(zipBlob),link=document.createElement('a');
        link.href=zipUrl;link.download='chatattic-images.zip';document.body.appendChild(link);link.click();link.remove();
        setTimeout(()=>URL.revokeObjectURL(zipUrl),60000);
        return {ok:true,images:entries.length,directFailed,mode:'images-only'};
      }
      const blob=new Blob([JSON.stringify(result,null,2)],{type:'application/json'});
      const a=document.createElement('a');const url=URL.createObjectURL(blob);
      a.href=url;a.download='chatgpt-conversation-complete.json';
      document.body.appendChild(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),60000);
      window.postMessage({source:'CHATATTIC_CONVERSATION_ARCHIVER',type:'CAPTURE_COMPLETE',detail:{completedAt:Date.now(),autoSaveOk:true,mode:'internal',directSaved,directFailed,count:result.length,images:result.reduce((n,x)=>n+x.images.length,0)}},'*');
      return {ok:true,count:result.length,directSaved,directFailed,images:result.reduce((n,x)=>n+x.images.length,0)};
    } catch(e) {return {ok:false,reason:'internal-error: '+String(e?.message||e)};}
  };
})();
