const statusEl = document.getElementById("status");

function status(text, cls=""){
  statusEl.textContent = text;
  statusEl.className = "status " + cls;
}

async function getChatTab(){
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id) throw new Error("現在のタブを取得できません。");
  if(!/^https:\/\/(?:chatgpt\.com|gemini\.google\.com)\//.test(tab.url || "")){
    throw new Error("ChatGPTまたはGeminiの会話ページで実行してください。");
  }
  return tab;
}

async function injectBridge(tabId){
  // Manifest更新直後など、既存タブにcontent scriptがまだいない場合の保険。
  await chrome.scripting.executeScript({
    target:{tabId},
    files:["bridge.js"]
  });
}

async function injectCapture(tabId){
  // Always replace the page's previous capture implementation. A page can
  // retain an old __startAutoCapture after an extension update.
  await chrome.scripting.executeScript({
    target:{tabId}, world:"MAIN", files:["capture.js"]
  });
}

async function prepare(tabId){
  await injectBridge(tabId);
  await injectCapture(tabId);
}

async function callMain(fn){
  const tab = await getChatTab();
  await prepare(tab.id);
  return chrome.scripting.executeScript({
    target:{tabId:tab.id},
    world:"MAIN",
    func:fn
  });
}

document.getElementById("saveAll").addEventListener("click", async ()=>{
  try{
    const tab = await getChatTab();
    status("捕獲の準備中…");

    await prepare(tab.id);

    // Prefer the active conversation tree when the authenticated endpoint works.
    // Fallback retains the known-working DOM scroll/capture path unchanged.
    if (/^https:\/\/chatgpt\.com\/c\//.test(tab.url || "")) {
      status("会話の内部データを確認中…");
      await chrome.scripting.executeScript({target:{tabId:tab.id},world:"MAIN",files:["internal-reader.js"]});
      const internal = await chrome.scripting.executeScript({
        target:{tabId:tab.id},world:"MAIN",func:()=>window.__chatAtticTryInternal()
      });
      const outcome = internal?.[0]?.result;
      if (outcome?.ok) {
        status(`本文${outcome.count}件、画像${outcome.directSaved??0}枚取得（未取得${outcome.directFailed??0}枚）。`,"ok");
        return;
      }
      console.info("ChatAttic: 内部データ取得不可、従来方式へ",outcome?.reason);
      status("内部データ取得不可。従来のスクロール方式に切り替えます…");
    }

    const probe = await chrome.scripting.executeScript({
      target:{tabId:tab.id}, world:"MAIN",
      func: async () => {
        await window.__capturePortableNow();
        return {
          captured: window.__chatCapturePortable?.size || 0,
          domCandidates: document.querySelectorAll('main .bg-user-message, main [class*="MarkdownRoot"]').length,
          scroller: !!window.__findChatScroller?.()
        };
      }
    });
    const info = probe?.[0]?.result;
    if (!info?.captured) {
      throw new Error(`捕獲0件（画面候補${info?.domCandidates ?? '?'}件）。保存せず停止しました。`);
    }
    status(`初回捕獲${info.captured}件。巡回を開始します…`);

    const result = await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      world:"MAIN",
      func:()=>{
        if (window.__chatAutoCaptureRunning) return "running";
        window.__startAutoCapture();
        return "started";
      }
    });

    if(result?.[0]?.result === "running"){
      status("すでに捕獲中です。完了後にJSON保存→アーカイブツールを開きます。","ok");
    }else{
      status("捕獲開始！ 完了後にJSON保存→アーカイブツールを開きます。","ok");
    }
  }catch(e){
    status(e.message || String(e),"bad");
  }
});

document.getElementById("stop").addEventListener("click", async ()=>{
  try{
    await callMain(()=>window.__stopAutoCapture());
    status("捕獲を停止しました。","ok");
  }catch(e){
    status(e.message || String(e),"bad");
  }
});

document.getElementById("save").addEventListener("click", async ()=>{
  try{
    await callMain(()=>window.__savePortableCapture());
    status("JSONを手動保存しました。","ok");
  }catch(e){
    status(e.message || String(e),"bad");
  }
});

document.getElementById("convert").addEventListener("click", ()=>{
  chrome.tabs.create({url:chrome.runtime.getURL("converter.html")});
});
// ChatGPT image-only ZIP export; no DOM scrolling and no converter tab.
document.getElementById("saveImages").addEventListener("click",async()=>{
  try{
    const tab=await getChatTab();
    if(!/^https:\/\/chatgpt\.com\/c\//.test(tab.url||""))throw new Error("画像のみZIP保存はChatGPTの会話ページ専用です。");
    status("画像を取得してZIPを作成中…");
    await chrome.scripting.executeScript({target:{tabId:tab.id},world:"MAIN",files:["internal-reader.js"]});
    const r=await chrome.scripting.executeScript({target:{tabId:tab.id},world:"MAIN",func:()=>window.__chatAtticTryInternal("images-only")});
    const outcome=r?.[0]?.result;
    if(!outcome?.ok)throw new Error(outcome?.reason||"画像保存に失敗しました。");
    status(`画像${outcome.images}枚をZIP保存しました（未取得${outcome.directFailed||0}枚）。`,"ok");
  }catch(e){status(e?.message||String(e),"bad");}
});
