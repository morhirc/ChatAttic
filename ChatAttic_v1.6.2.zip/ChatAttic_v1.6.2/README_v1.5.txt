ChatAttic v1.5
ChatGPT会話の高速保存・画像直接取得に加え、画像のみZIP保存を追加。画像ZIPは元画像形式（PNG/JPEG/GIF/WebP）でTurn番号別に格納します。画像の取得に失敗した場合、その画像はZIPに入りません。Geminiの画像ZIP保存は非対応。既存の会話保存ロジックは維持しています。
