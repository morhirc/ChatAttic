(async () => {
  const loading = document.getElementById("loading");
  const errorBox = document.getElementById("error");
  const root = document.getElementById("archiveRoot");

  function fail(msg){
    loading.style.display = "none";
    errorBox.style.display = "block";
    errorBox.textContent = msg;
  }

  try{
    const params = new URLSearchParams(location.search);
    const src = params.get("src");
    if(!src) throw new Error("会話HTMLの受け渡し情報がありません。");

    const res = await fetch(src);
    if(!res.ok) throw new Error("会話HTMLを読み込めませんでした。");
    const text = await res.text();

    const doc = new DOMParser().parseFromString(text, "text/html");

    // 保存HTMLのCSSを取り込む。ただし外部通信につながる @import / url(http...) は除去する。
    function sanitizeCss(css){
      return String(css || "")
        .replace(/@import\s+(?:url\()?['"]?https?:\/\/[^;)"']+['"]?\)?\s*;?/gi, "/* blocked external import */")
        .replace(/url\(\s*(['"]?)https?:\/\/[^)"']+\1\s*\)/gi, "none");
    }

    [...doc.head.querySelectorAll("style")].forEach(style => {
      const clone = document.createElement("style");
      clone.textContent = sanitizeCss(style.textContent);
      document.head.appendChild(clone);
    });

    // ブラウザのタブ名は用途が一目で分かるよう固定する。
    document.title = "ChatAtticビューア";

    // bodyを移植する前に、実行可能要素・外部読み込み・イベント属性を無効化する。
    const bodyClone = doc.body.cloneNode(true);

    // 読み込み/実行系タグは不要なので丸ごと除去。
    bodyClone.querySelectorAll("script,iframe,object,embed,link,meta,base,form,video,audio,source,track").forEach(el => el.remove());

    const URL_ATTRS = new Set(["src","srcset","href","xlink:href","poster","action","formaction"]);
    bodyClone.querySelectorAll("*").forEach(el => {
      for(const attr of [...el.attributes]){
        const name = attr.name.toLowerCase();
        const value = String(attr.value || "").trim();

        // onclick などのイベントハンドラ、srcdoc は常に削除。
        if(name.startsWith("on") || name === "srcdoc"){
          el.removeAttribute(attr.name);
          continue;
        }

        // style属性中の外部URLも遮断。
        if(name === "style"){
          el.setAttribute(attr.name, sanitizeCss(value));
          continue;
        }

        if(URL_ATTRS.has(name)){
          // 画像は本ツールが埋め込む data:image / blob のみ許可。
          if(name === "src" && el.tagName === "IMG"){
            if(!/^(?:data:image\/|blob:)/i.test(value)) el.removeAttribute(attr.name);
            continue;
          }

          // ページ内アンカー以外のリンク/URLは無効化。
          if(name === "href" && /^#[A-Za-z0-9_.:-]*$/.test(value)) continue;
          el.removeAttribute(attr.name);
        }
      }
    });

    root.replaceChildren(...bodyClone.childNodes);

    loading.style.display = "none";

    // ----- 検索・表示切替 -----
    const search = document.getElementById("search");
    const clear = document.getElementById("clear");
    const dateToggle = document.getElementById("dateToggle");
    const datePanel = document.getElementById("datePanel");
    const dateFrom = document.getElementById("dateFrom");
    const dateTo = document.getElementById("dateTo");
    const dateClear = document.getElementById("dateClear");
    const msgs = [...document.querySelectorAll(".msg")];
    const resultCount = document.getElementById("resultCount");
    const searchPrev = document.getElementById("searchPrev");
    const searchNext = document.getElementById("searchNext");
    const searchCount = document.getElementById("searchCount");
    const turnStatus = document.getElementById("turnStatus");
    const buttons = {
      all: document.getElementById("showAll"),
      user: document.getElementById("showUser"),
      assistant: document.getElementById("showAssistant")
    };

    let roleFilter = "all";
    let marks = [];
    let currentMark = -1;

    function updateButtons(){
      Object.entries(buttons).forEach(([k,b])=>{
        if(b) b.classList.toggle("active", k === roleFilter);
      });
    }

    function normalize(s){
      return String(s ?? "").normalize("NFKC").toLocaleLowerCase("ja");
    }

    function clearMarks(){
      document.querySelectorAll(".searchmark").forEach(mark=>{
        const parent = mark.parentNode;
        parent.replaceChild(document.createTextNode(mark.textContent), mark);
        parent.normalize();
      });
      marks = [];
      currentMark = -1;
    }

    function markText(rootEl, query){
      if(!query) return;

      const walker = document.createTreeWalker(
        rootEl,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode(node){
            if(!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
            if(node.parentElement?.closest("script,style,pre,code,header")) {
              return NodeFilter.FILTER_REJECT;
            }
            return NodeFilter.FILTER_ACCEPT;
          }
        }
      );

      const nodes = [];
      while(walker.nextNode()) nodes.push(walker.currentNode);

      const qNorm = normalize(query);

      nodes.forEach(node=>{
        const raw = node.nodeValue;
        const norm = normalize(raw);
        let from = 0;
        let found = false;
        const parts = [];

        while(true){
          const idx = norm.indexOf(qNorm, from);
          if(idx < 0) break;

          found = true;
          if(idx > from) parts.push(document.createTextNode(raw.slice(from, idx)));

          const mark = document.createElement("mark");
          mark.className = "searchmark";
          mark.textContent = raw.slice(idx, idx + query.length);
          parts.push(mark);

          from = idx + query.length;
        }

        if(found){
          if(from < raw.length) parts.push(document.createTextNode(raw.slice(from)));
          const frag = document.createDocumentFragment();
          parts.forEach(p=>frag.appendChild(p));
          node.parentNode.replaceChild(frag, node);
        }
      });
    }

    function refreshMarks(){
      marks = [...document.querySelectorAll(".searchmark")]
        .filter(m=>!m.closest(".hidden"));

      if(!marks.length){
        currentMark = -1;
        if(searchCount){
          searchCount.textContent = "0 / 0";
          searchCount.classList.toggle("idle", !search?.value.trim());
        }
        return;
      }

      if(currentMark < 0 || currentMark >= marks.length) currentMark = 0;

      marks.forEach((m,i)=>m.classList.toggle("current", i === currentMark));
      if(searchCount){
        searchCount.textContent = (currentMark + 1) + " / " + marks.length;
        searchCount.classList.remove("idle");
      }
    }

    function gotoMark(delta){
      if(!marks.length) return;

      currentMark = (currentMark + delta + marks.length) % marks.length;
      marks.forEach((m,i)=>m.classList.toggle("current", i === currentMark));
      if(searchCount){
        searchCount.textContent = (currentMark + 1) + " / " + marks.length;
        searchCount.classList.remove("idle");
      }
      marks[currentMark].scrollIntoView({behavior:"smooth", block:"center"});
    }

    function applyFilters(){
      if(!search) return;

      const q = search.value.trim();
      let visible = 0;

      clearMarks();

      msgs.forEach(m=>{
        const roleOk = roleFilter === "all" || m.dataset.role === roleFilter;
        const textOk = !q || normalize(m.innerText).includes(normalize(q));
        const d = m.dataset.date || "";
        const dateOk = (!dateFrom?.value || (d && d >= dateFrom.value)) &&
                       (!dateTo?.value || (d && d <= dateTo.value));
        const show = roleOk && textOk && dateOk;

        m.classList.toggle("hidden", !show);
        if(show) visible++;
      });

      if(resultCount) resultCount.textContent = "表示 " + visible + "件";

      if(q){
        msgs
          .filter(m=>!m.classList.contains("hidden"))
          .forEach(m=>markText(m, q));
      }

      refreshMarks();
    }

    search?.addEventListener("input", ()=>{
      clear?.classList.toggle("show", !!search.value);
      applyFilters();
    });

    clear?.addEventListener("click", ()=>{
      search.value = "";
      clear.classList.remove("show");
      applyFilters();
      search.focus();
    });

    dateToggle?.addEventListener("click", ()=>datePanel?.classList.toggle("open"));
    dateFrom?.addEventListener("change", applyFilters);
    dateTo?.addEventListener("change", applyFilters);
    dateClear?.addEventListener("click", ()=>{
      if(dateFrom) dateFrom.value = "";
      if(dateTo) dateTo.value = "";
      applyFilters();
    });

    searchPrev?.addEventListener("click", ()=>gotoMark(-1));
    searchNext?.addEventListener("click", ()=>gotoMark(1));

    search?.addEventListener("keydown", e=>{
      if(e.key === "Enter"){
        e.preventDefault();
        gotoMark(e.shiftKey ? -1 : 1);
      }
    });

    buttons.all?.addEventListener("click", ()=>{
      roleFilter = "all";
      updateButtons();
      applyFilters();
    });
    buttons.user?.addEventListener("click", ()=>{
      roleFilter = "user";
      updateButtons();
      applyFilters();
    });
    buttons.assistant?.addEventListener("click", ()=>{
      roleFilter = "assistant";
      updateButtons();
      applyFilters();
    });

    // ----- Turnジャンプ / 現在Turn / 先頭・最後 -----
    document.getElementById("top")?.addEventListener("click", ()=>{
      window.scrollTo({top:0, behavior:"smooth"});
    });

    document.getElementById("bottom")?.addEventListener("click", ()=>{
      window.scrollTo({
        top:document.documentElement.scrollHeight,
        behavior:"smooth"
      });
    });

    const turnInput = document.getElementById("turnInput");
    const jumpTurn = document.getElementById("jumpTurn");

    jumpTurn?.addEventListener("click", ()=>{
      const n = turnInput?.value?.trim();
      if(!n) return;

      msgs.forEach(m=>m.classList.remove("highlight"));
      const target = msgs.find(m=>m.dataset.turn === n);

      if(target){
        target.classList.remove("hidden");
        target.classList.add("highlight");
        target.scrollIntoView({behavior:"smooth", block:"start"});
        setTimeout(()=>target.classList.remove("highlight"), 2200);
      }else{
        alert("Turn " + n + " は見つかりませんでした");
      }
    });

    turnInput?.addEventListener("keydown", e=>{
      if(e.key === "Enter") jumpTurn?.click();
    });

    const allTurns = msgs
      .map(m=>Number(m.dataset.turn))
      .filter(Number.isFinite);

    const maxTurn = allTurns.length
      ? Math.max(...allTurns)
      : msgs.length;

    function updateTurnStatus(){
      if(!turnStatus) return;

      let current = null;
      const y = window.scrollY + 110;

      for(const m of msgs){
        if(m.offsetTop <= y) current = m;
        else break;
      }

      const turn = current?.dataset.turn || (msgs[0]?.dataset.turn ?? "-");
      turnStatus.textContent = "Turn " + turn + " / " + maxTurn;
    }

    window.addEventListener("scroll", updateTurnStatus, {passive:true});
    window.addEventListener("resize", updateTurnStatus);

    // ----- 画像拡大 -----
    const lb = document.getElementById("lightbox");
    const lbImg = lb?.querySelector("img");
    const lbCap = document.getElementById("lbcap");
    const galleryImgs = [...document.querySelectorAll(".shot img")];
    let currentIndex = -1;

    function openAt(i){
      if(!lb || !lbImg || !galleryImgs.length) return;
      currentIndex = (i + galleryImgs.length) % galleryImgs.length;
      const img = galleryImgs[currentIndex];
      lbImg.src = img.src;
      lbImg.alt = img.alt;
      const turn = img.closest(".msg")?.dataset.turn || "";
      if(lbCap){
        lbCap.textContent =
          "Turn " + turn + " / " + (img.alt || "画像") +
          " / " + (currentIndex+1) + " of " + galleryImgs.length;
      }
      lb.classList.add("open");
      lb.setAttribute("aria-hidden","false");
    }

    galleryImgs.forEach((img,i)=>{
      img.addEventListener("click", e=>{
        e.stopPropagation();
        openAt(i);
      });
    });

    function closeLB(){
      if(!lb || !lbImg) return;
      lb.classList.remove("open");
      lb.setAttribute("aria-hidden","true");
      lbImg.src = "";
    }

    document.getElementById("prev")?.addEventListener("click", e=>{
      e.stopPropagation(); openAt(currentIndex-1);
    });
    document.getElementById("next")?.addEventListener("click", e=>{
      e.stopPropagation(); openAt(currentIndex+1);
    });
    lb?.addEventListener("click", closeLB);

    document.addEventListener("keydown", e=>{
      if(!lb?.classList.contains("open")) return;
      if(e.key === "Escape") closeLB();
      if(e.key === "ArrowLeft") openAt(currentIndex-1);
      if(e.key === "ArrowRight") openAt(currentIndex+1);
    });

    updateButtons();
    applyFilters();
    updateTurnStatus();

  }catch(e){
    fail("会話アーカイブを開けませんでした：" + (e?.message || String(e)));
  }
})();