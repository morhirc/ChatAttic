(() => {
  if (window.__chatArchiveBridgeV16Installed) return;
  window.__chatArchiveBridgeV16Installed = true;

  let lastCompletedAt = 0;

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;

    const data = event.data;
    if (!data || !["CHATGPT_CONVERSATION_ARCHIVER","CHATATTIC_CONVERSATION_ARCHIVER"].includes(data.source)) return;
    if (data.type !== "CAPTURE_COMPLETE") return;

    const completedAt = Number(data?.detail?.completedAt || Date.now());
    if (completedAt === lastCompletedAt) return;
    lastCompletedAt = completedAt;

    chrome.runtime.sendMessage({
      type: "capture-complete-v16",
      detail: data.detail || {}
    }).catch(() => {});
  });
})();