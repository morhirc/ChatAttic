(() => {
  // =========================================================
  // ChatGPT会話捕獲ツール v4.1
  // 本文 + 画像 + 元アップロード画像 + 全自動巡回
  // =========================================================

  // ---------------------------------------------------------
  // 古い監視・自動運転を停止
  // ---------------------------------------------------------

  try {
    window.__chatObserver?.disconnect();
  } catch {}

  try {
    window.__chatPortableAbort?.abort();
  } catch {}

  try {
    if (window.__chatAutoScrollTimer) {
      clearInterval(window.__chatAutoScrollTimer);
    }
  } catch {}

  // ---------------------------------------------------------
  // 保存場所
  // ---------------------------------------------------------

  window.__chatCapturePortable = new Map();

  // S級修正: ChatGPTの巨大/古い会話では data-testid の
  // conversation-turn-N が仮想スクロール中に再利用される場合がある。
  // その番号を絶対順序として使わず、各スナップショットのDOM順から
  // メッセージID同士の前後関係を蓄積し、保存時に順序を復元する。
  window.__chatOrderEdges = new Map();
  window.__chatFirstSeen = new Map();
  window.__chatFirstSeenCounter = 0;

  window.__chatUploadCache = new Map();

  window.__chatUploadQueue = [];

  window.__chatPortableAbort =
    new AbortController();

  window.__chatAutoCaptureRunning = false;

  window.__chatAutoScrollTimer = null;

  const signal =
    window.__chatPortableAbort.signal;

  // =========================================================
  // 1. アップロード元画像を確保
  // =========================================================

  window.__captureUploadFile =
    async (file) => {

      if (!file) {
        return;
      }

      if (
        !file.type?.startsWith("image/")
      ) {
        return;
      }

      const dataUrl =
        await new Promise(
          (resolve, reject) => {

            const reader =
              new FileReader();

            reader.onload =
              () => {
                resolve(
                  reader.result
                );
              };

            reader.onerror =
              () => {
                reject(
                  reader.error
                );
              };

            reader.readAsDataURL(
              file
            );
          }
        );

      const entry = {
        alt:
          file.name || null,

        name:
          file.name || null,

        type:
          file.type || null,

        size:
          file.size || null,

        dataUrl:
          dataUrl,

        capturedAt:
          Date.now(),

        used:
          false
      };

      if (file.name) {
        window
          .__chatUploadCache
          .set(
            file.name,
            entry
          );
      }

      window
        .__chatUploadQueue
        .push(entry);

      console.log(
        "📸 元画像を確保:",
        file.name ||
          "(名前なし)",
        file.size,
        "bytes"
      );
    };

  // =========================================================
  // 2. change / paste / drop 監視
  // =========================================================

  window.__installUploadWatch =
    () => {

      const handleFiles =
        async (
          files,
          source
        ) => {

          if (!files?.length) {
            return;
          }

          for (
            const file of files
          ) {
            await window
              .__captureUploadFile(
                file
              );
          }

          console.log(
            "🚨 元ファイル捕獲:",
            source,
            files.length,
            "件"
          );
        };

      // ファイル選択
      document.addEventListener(
        "change",
        async (e) => {

          const input =
            e.target;

          if (
            input
              instanceof
              HTMLInputElement &&
            input.type ===
              "file" &&
            input.files?.length
          ) {
            await handleFiles(
              [...input.files],
              "change"
            );
          }
        },
        {
          capture: true,
          signal: signal
        }
      );

      // クリップボード貼り付け
      document.addEventListener(
        "paste",
        async (e) => {

          if (
            e.clipboardData
              ?.files
              ?.length
          ) {
            await handleFiles(
              [
                ...e
                  .clipboardData
                  .files
              ],
              "paste"
            );
          }
        },
        {
          capture: true,
          signal: signal
        }
      );

      // ドラッグ＆ドロップ
      document.addEventListener(
        "drop",
        async (e) => {

          if (
            e.dataTransfer
              ?.files
              ?.length
          ) {
            await handleFiles(
              [
                ...e
                  .dataTransfer
                  .files
              ],
              "drop"
            );
          }
        },
        {
          capture: true,
          signal: signal
        }
      );

      console.log(
        "🚓 画像アップロード待ち伏せ開始 " +
        "(change / paste / drop)"
      );
    };

  // =========================================================
  // 3. img → 画像本体
  // =========================================================

  async function imageToDataURL(
    img
  ) {

    const src =
      img.currentSrc ||
      img.src;

    if (!src) {
      return null;
    }

    // faviconは画像として扱わない
    if (
      src.includes(
        "google.com/s2/favicons"
      )
    ) {
      return null;
    }

    // -------------------------------------------------------
    // A. ファイル名一致の元画像
    // -------------------------------------------------------

    if (img.alt) {

      const cached =
        window
          .__chatUploadCache
          .get(
            img.alt
          );

      if (
        cached?.dataUrl
      ) {

        cached.used = true;

        return {
          alt:
            img.alt ||
            cached.alt,

          src:
            src,

          width:
            img.naturalWidth ||
            null,

          height:
            img.naturalHeight ||
            null,

          type:
            cached.type,

          size:
            cached.size,

          dataUrl:
            cached.dataUrl,

          source:
            "upload-cache"
        };
      }
    }

    // -------------------------------------------------------
    // B. blob画像
    //
    // blobを後から取らず、
    // 添付時に確保済みの元画像を使う
    // -------------------------------------------------------

    if (
      src.startsWith(
        "blob:"
      )
    ) {

      const pending =
        [
          ...window
            .__chatUploadQueue
        ]
          .reverse()
          .find(
            x =>
              !x.used &&
              x.dataUrl
          );

      if (pending) {

        pending.used = true;

        return {
          alt:
            img.alt ||
            pending.alt,

          src:
            src,

          width:
            img.naturalWidth ||
            null,

          height:
            img.naturalHeight ||
            null,

          type:
            pending.type,

          size:
            pending.size,

          dataUrl:
            pending.dataUrl,

          source:
            "upload-queue"
        };
      }

      return {
        alt:
          img.alt ||
          null,

        src:
          src,

        error:
          "blob画像: 元アップロード画像を捕獲できませんでした"
      };
    }

    // -------------------------------------------------------
    // C. 通常画像
    // -------------------------------------------------------

    try {

      const res =
        await fetch(
          src,
          {
            credentials:
              "include"
          }
        );

      if (!res.ok) {
        throw new Error(
          "HTTP " +
          res.status
        );
      }

      const blob =
        await res.blob();

      const dataUrl =
        await new Promise(
          (
            resolve,
            reject
          ) => {

            const reader =
              new FileReader();

            reader.onload =
              () => {
                resolve(
                  reader.result
                );
              };

            reader.onerror =
              () => {
                reject(
                  reader.error
                );
              };

            reader
              .readAsDataURL(
                blob
              );
          }
        );

      return {
        alt:
          img.alt ||
          null,

        src:
          src,

        width:
          img.naturalWidth ||
          null,

        height:
          img.naturalHeight ||
          null,

        type:
          blob.type ||
          null,

        size:
          blob.size ||
          null,

        dataUrl:
          dataUrl,

        source:
          "fetch"
      };

    } catch (e) {

      return {
        alt:
          img.alt ||
          null,

        src:
          src,

        error:
          String(e)
      };
    }
  }

  // =========================================================
  // 4. 現在表示されている会話を捕獲
  // ChatGPT / Gemini 自動判定
  // =========================================================

  window.__chatAtticProvider =
    location.hostname === "gemini.google.com"
      ? "gemini"
      : "chatgpt";

  async function captureImagesForItem(scope, item) {
    if (!scope || !item) return;

    const imgs = [...scope.querySelectorAll("img")];

    for (const img of imgs) {
      const src = img.currentSrc || img.src;
      if (!src) continue;

      // UIアイコン / favicon / アバター等はなるべく除外
      if (
        src.includes("google.com/s2/favicons") ||
        src.includes("gemini_sparkle") ||
        src.includes("googleusercontent.com/a/")
      ) {
        continue;
      }

      if (
        !img.alt &&
        !src.startsWith("blob:") &&
        !src.startsWith("data:image") &&
        !src.includes("/backend-api/estuary/") &&
        !src.includes("googleusercontent.com")
      ) {
        continue;
      }

      if (item.images.some(x => x.src === src)) continue;

      const captured = await imageToDataURL(img);
      if (!captured) continue;
      item.images.push(captured);
    }
  }

  function isRenderableChatMessage(el) {
    if (!el || !el.isConnected) return false;

    // SPAが保持している非表示の旧画面・分岐を除外する。
    // viewport外でも、レイアウト上に存在する要素は残す。
    let node = el;
    for (let i = 0; node && i < 14; i++, node = node.parentElement) {
      if (node.hidden || node.inert) return false;
      if (node.getAttribute?.("aria-hidden") === "true") return false;

      const style = getComputedStyle(node);
      if (style.display === "none" || style.visibility === "hidden") return false;
    }

    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function rememberChatGPTSnapshot(ids) {
    // 同一スナップショット内の重複を除去しつつDOM順を保持。
    const ordered = [];
    const seen = new Set();

    for (const id of ids) {
      if (!id || seen.has(id)) continue;
      seen.add(id);
      ordered.push(id);

      if (!window.__chatFirstSeen.has(id)) {
        window.__chatFirstSeen.set(id, window.__chatFirstSeenCounter++);
      }
      if (!window.__chatOrderEdges.has(id)) {
        window.__chatOrderEdges.set(id, new Set());
      }
    }

    // 連続するメッセージの「AはBより前」を記録する。
    for (let i = 0; i + 1 < ordered.length; i++) {
      const a = ordered[i];
      const b = ordered[i + 1];
      if (a !== b) window.__chatOrderEdges.get(a).add(b);
    }
  }

  function getOrderedChatGPTItems() {
    const items = [...window.__chatCapturePortable.values()]
      .filter(x => x.provider === "chatgpt");

    const byId = new Map(items.map(x => [x.id, x]));
    const indegree = new Map();
    const edges = new Map();

    for (const id of byId.keys()) {
      indegree.set(id, 0);
      edges.set(id, new Set());
    }

    // 捕獲済みメッセージ間だけの前後関係を採用。
    for (const [a, tos] of window.__chatOrderEdges.entries()) {
      if (!byId.has(a)) continue;
      for (const b of tos) {
        if (!byId.has(b) || a === b || edges.get(a).has(b)) continue;
        edges.get(a).add(b);
        indegree.set(b, indegree.get(b) + 1);
      }
    }

    const firstSeen = id => window.__chatFirstSeen.get(id) ?? Number.MAX_SAFE_INTEGER;
    const sourceTurn = id => Number(byId.get(id)?.sourceTurn ?? Number.MAX_SAFE_INTEGER);

    // Kahn法。候補が複数なら、旧turnは補助情報としてのみ使い、
    // 最後は初回捕獲順で決定する。
    const ready = [...byId.keys()].filter(id => indegree.get(id) === 0);
    const sortReady = () => ready.sort((a, b) => {
      // 自動捕獲は下→上へ進むため、別コンポーネントになった場合は
      // 「後から初めて見えたもの」ほど会話の前方にある可能性が高い。
      // conversation-turn-N は巨大ログで再利用され得るため、ここでは使わない。
      return firstSeen(b) - firstSeen(a);
    });
    sortReady();

    const orderedIds = [];
    while (ready.length) {
      const id = ready.shift();
      orderedIds.push(id);

      for (const b of edges.get(id) || []) {
        indegree.set(b, indegree.get(b) - 1);
        if (indegree.get(b) === 0) {
          ready.push(b);
          sortReady();
        }
      }
    }

    // DOM差し替え等で矛盾した辺が混ざりサイクルになった場合でも
    // メッセージを捨てない。未確定分は補助情報で安定的に末尾へ並べる。
    if (orderedIds.length !== byId.size) {
      const done = new Set(orderedIds);
      const rest = [...byId.keys()].filter(id => !done.has(id));
      rest.sort((a, b) => firstSeen(b) - firstSeen(a));
      orderedIds.push(...rest);
      console.warn("⚠️ ChatAttic順序復元: 一部の前後関係が循環したため補助順序を使用", rest.length);
    }

    return orderedIds.map((id, index) => {
      const item = byId.get(id);
      // ChatAtticのturnは保存時の絶対メッセージ順として振り直す。
      return { ...item, turn: index + 1 };
    });
  }

  async function captureChatGPTNow() {
    // ChatGPT SPA内に残る非表示の旧画面/分岐を拾わないよう、
    // 実際にレイアウトされているメッセージだけを対象にする。
    const messageElements = [
      ...document.querySelectorAll("main [data-message-author-role], [role='main'] [data-message-author-role]")
    ].filter(isRenderableChatMessage);

    const snapshotIds = [];

    for (const el of messageElements) {
      const id = el.closest("[data-message-id]")?.getAttribute("data-message-id");
      const turnEl = el.closest('[data-testid^="conversation-turn-"]');
      const turnText = turnEl?.getAttribute("data-testid");
      const sourceTurn = turnText
        ? Number(turnText.replace("conversation-turn-", ""))
        : null;

      if (!id || !turnEl) continue;

      snapshotIds.push(id);

      let item = window.__chatCapturePortable.get(id);

      if (!item) {
        item = {
          provider: "chatgpt",
          turn: sourceTurn,
          sourceTurn,
          id,
          role: el.getAttribute("data-message-author-role"),
          text: el.innerText,
          images: []
        };
        window.__chatCapturePortable.set(id, item);
      } else {
        item.provider = "chatgpt";
        item.sourceTurn = sourceTurn;
        item.role = el.getAttribute("data-message-author-role");
        item.text = el.innerText;
      }

      await captureImagesForItem(turnEl, item);
    }

    rememberChatGPTSnapshot(snapshotIds);
  }

  function cleanGeminiUserText(turnEl) {
    const line = turnEl.querySelector("user-query .query-text-line");
    if (line?.innerText?.trim()) return line.innerText.trim();

    const q = turnEl.querySelector("user-query .query-text");
    if (!q) return "";

    const clone = q.cloneNode(true);
    clone.querySelectorAll(".cdk-visually-hidden,[aria-hidden='true']").forEach(x => x.remove());
    return clone.innerText.trim();
  }

  function cleanGeminiAssistantText(turnEl) {
    const content =
      turnEl.querySelector("model-response message-content .markdown") ||
      turnEl.querySelector("model-response message-content") ||
      turnEl.querySelector("model-response structured-content-container");

    if (!content) return "";

    const clone = content.cloneNode(true);
    clone.querySelectorAll(
      ".cdk-visually-hidden,.model-response-label-announcer,.source-inline-chip-container," +
      "sources-carousel-inline,source-inline-chip,button,[aria-hidden='true']"
    ).forEach(x => x.remove());

    return clone.innerText.trim();
  }

  async function captureGeminiNow() {
    const turns = [
      ...document.querySelectorAll("#chat-history .conversation-container, div.conversation-container")
    ];

    // querySelectorAllの重複を除外し、DOM順で扱う
    const uniqueTurns = [...new Set(turns)];

    for (let i = 0; i < uniqueTurns.length; i++) {
      const turnEl = uniqueTurns[i];
      const baseId = turnEl.id || `gemini-turn-${i + 1}`;
      const userEl = turnEl.querySelector("user-query");
      const assistantEl = turnEl.querySelector("model-response");

      const userText = cleanGeminiUserText(turnEl);
      const assistantText = cleanGeminiAssistantText(turnEl);

      if (userEl && userText) {
        const id = `${baseId}:user`;
        let item = window.__chatCapturePortable.get(id);
        if (!item) {
          item = {
            provider: "gemini",
            turn: i * 2 + 1,
            id,
            role: "user",
            text: userText,
            images: []
          };
          window.__chatCapturePortable.set(id, item);
        } else {
          item.provider = "gemini";
          item.turn = i * 2 + 1;
          item.text = userText;
        }
        await captureImagesForItem(userEl, item);
      }

      if (assistantEl && assistantText) {
        const id = `${baseId}:assistant`;
        let item = window.__chatCapturePortable.get(id);
        if (!item) {
          item = {
            provider: "gemini",
            turn: i * 2 + 2,
            id,
            role: "assistant",
            text: assistantText,
            images: []
          };
          window.__chatCapturePortable.set(id, item);
        } else {
          item.provider = "gemini";
          item.turn = i * 2 + 2;
          item.text = assistantText;
        }
        await captureImagesForItem(assistantEl, item);
      }
    }
  }

  window.__capturePortableNow = async () => {
    if (window.__chatAtticProvider === "gemini") {
      await captureGeminiNow();
    } else {
      await captureChatGPTNow();
    }

    const all = [...window.__chatCapturePortable.values()];
    const imageCount = all.reduce((n, x) => n + (x.images?.length || 0), 0);
    const embeddedCount = all
      .flatMap(x => x.images || [])
      .filter(x => !!x.dataUrl).length;

    console.log(
      `📦 ChatAttic ${window.__chatAtticProvider} 捕獲:`,
      all.length,
      "メッセージ / 📸",
      imageCount,
      "画像 / 💾",
      embeddedCount,
      "画像本体"
    );
  };

  // =========================================================
  // 5. JSON保存
  // =========================================================

  window.__savePortableCapture =
    () => {

      const complete =
        window.__chatAtticProvider === "chatgpt"
          ? getOrderedChatGPTItems()
          : [
              ...window
                .__chatCapturePortable
                .values()
            ]
              .sort(
                (a, b) =>
                  a.turn -
                  b.turn
              );

      const blob =
        new Blob(
          [
            JSON.stringify(
              complete,
              null,
              2
            )
          ],
          {
            type:
              "application/json"
          }
        );

      const a =
        document
          .createElement(
            "a"
          );

      a.href =
        URL.createObjectURL(
          blob
        );

      a.download =
        window.__chatAtticProvider === "gemini"
          ? "gemini-conversation-complete.json"
          : "chatgpt-conversation-complete.json";

      document.body
        .appendChild(a);

      a.click();

      a.remove();

      setTimeout(
        () => {
          URL
            .revokeObjectURL(
              a.href
            );
        },
        5000
      );

      console.log(
        "💾 保存しました:",
        complete.length,
        "メッセージ"
      );
    };

  // =========================================================
  // 6. ChatGPTのスクロール担当を自動検出
  // =========================================================

  window.__findChatScroller =
    () => {

      if (window.__chatAtticProvider === "gemini") {
        const geminiScroller =
          document.querySelector("#chat-history.chat-history-scroll-container") ||
          document.querySelector("#chat-history") ||
          document.querySelector("infinite-scroller[data-test-id='chat-history-container']")?.parentElement;

        if (geminiScroller) return geminiScroller;
      }

      const candidates =
        [
          ...document
            .querySelectorAll(
              "*"
            )
        ]
          .filter(
            el => {

              const s =
                getComputedStyle(
                  el
                );

              return (
                el.scrollHeight >
                  el.clientHeight +
                  100 &&
                (
                  s.overflowY ===
                    "auto" ||
                  s.overflowY ===
                    "scroll"
                )
              );
            }
          )
          .sort(
            (a, b) =>
              (
                b.scrollHeight -
                b.clientHeight
              ) -
              (
                a.scrollHeight -
                a.clientHeight
              )
          );

      return (
        candidates[0] ||
        null
      );
    };

  // =========================================================
  // 7. 全自動捕獲停止
  // =========================================================

  window.__stopAutoCapture =
    () => {

      if (
        window
          .__chatAutoScrollTimer
      ) {

        clearInterval(
          window
            .__chatAutoScrollTimer
        );

        window
          .__chatAutoScrollTimer =
          null;
      }

      window
        .__chatAutoCaptureRunning =
        false;

      console.log(
        "🛑 全自動捕獲を手動停止"
      );
    };

  // =========================================================
  // 8. 全自動捕獲開始
  //
  // 下 → 上 → 下
  // 自動巡回しながら捕獲
  // =========================================================

  window.__startAutoCapture =
    async () => {

      if (
        window
          .__chatAutoCaptureRunning
      ) {

        console.log(
          "⚠️ 全自動捕獲はすでに動作中です"
        );

        return;
      }

      const scroller =
        window
          .__findChatScroller();

      if (!scroller) {

        console.error(
          "❌ 会話のスクロール領域を発見できません"
        );

        return;
      }

      window
        .__chatAutoCaptureRunning =
        true;

      window
        .__chatAutoScroller =
        scroller;

      // -1 = 上
      //  1 = 下
      let direction = -1;

      let lastTop =
        scroller.scrollTop;

      let stuckCount = 0;

      let tickBusy = false;

      // 実験で成功した速度
      const STEP = 700;

      const INTERVAL = 500;

      // 端で8回動かなければ到着判定
      const EDGE_TICKS = 8;

      console.log(
        "🚂 全自動捕獲開始：上へ出発",
        "scrollTop:",
        Math.round(
          scroller.scrollTop
        )
      );

      // 出発地点を捕獲
      await window
        .__capturePortableNow();

      window
        .__chatAutoScrollTimer =
        setInterval(
          async () => {

            if (
              tickBusy ||
              !window
                .__chatAutoCaptureRunning
            ) {
              return;
            }

            tickBusy = true;

            try {

              scroller.scrollBy({
                top:
                  direction *
                  STEP,

                behavior:
                  "auto"
              });

              // DOM差し替え待ち
              await new Promise(
                resolve =>
                  setTimeout(
                    resolve,
                    180
                  )
              );

              // 新しく見えたTurnを捕獲
              await window
                .__capturePortableNow();

              const now =
                scroller.scrollTop;

              if (
                Math.abs(
                  now -
                  lastTop
                ) < 5
              ) {
                stuckCount++;
              } else {
                stuckCount = 0;
              }

              lastTop = now;

              // -----------------------------------------------
              // 上端
              // -----------------------------------------------

if (
  direction === -1 &&
  stuckCount >= EDGE_TICKS
) {
  clearInterval(
    window.__chatAutoScrollTimer
  );

  window.__chatAutoScrollTimer =
    null;

  window.__chatAutoCaptureRunning =
    false;

  console.log(
    "🏔️ 上端到着：片道運転終了"
  );

  // 上端の描画を待って最終捕獲
  await new Promise(
    resolve =>
      setTimeout(
        resolve,
        1200
      )
  );

  await window
    .__capturePortableNow();

  const all =
    [
      ...window
        .__chatCapturePortable
        .values()
    ];

  const imageCount =
    all.reduce(
      (n, x) =>
        n +
        (
          x.images?.length ||
          0
        ),
      0
    );

  const embeddedCount =
    all
      .flatMap(
        x =>
          x.images ||
          []
      )
      .filter(
        x =>
          !!x.dataUrl
      )
      .length;

  console.log(
    "🎉 v4.1 片道捕獲完了:",
    all.length,
    "メッセージ / 📸",
    imageCount,
    "画像 / 💾",
    embeddedCount,
    "画像本体"
  );

  console.log(
    "💾 JSON保存：__savePortableCapture()"
  );

  // v1.6:
  // 捕獲が完了した「このページ自身」のコンテキストでJSON保存を実行する。
  // 拡張のService Workerから保存関数を呼び戻す往復をやめ、安定性を上げる。
  let autoSaveOk = false;
  let autoSaveError = null;

  try {
    if (typeof window.__savePortableCapture === "function") {
      window.__savePortableCapture();
      autoSaveOk = true;
      console.log("✅ v1.6 JSON自動保存を実行");
    } else {
      throw new Error("__savePortableCapture が見つかりません");
    }
  } catch (e) {
    autoSaveError = String(e?.message || e);
    console.error("❌ v1.6 JSON自動保存失敗:", e);
  }

  // ダウンロード開始を少し待ってから、常駐content scriptへ完了通知。
  setTimeout(() => {
    window.postMessage({
      source: "CHATATTIC_CONVERSATION_ARCHIVER",
      type: "CAPTURE_COMPLETE",
      detail: {
        messages: all.length,
        images: imageCount,
        embedded: embeddedCount,
        completedAt: Date.now(),
        autoSaveOk,
        autoSaveError
      }
    }, "*");
  }, 500);

  return;
}
              // -----------------------------------------------
              // 下端
              // -----------------------------------------------

              if (
                direction === 1 &&
                stuckCount >=
                  EDGE_TICKS
              ) {

                clearInterval(
                  window
                    .__chatAutoScrollTimer
                );

                window
                  .__chatAutoScrollTimer =
                  null;

                window
                  .__chatAutoCaptureRunning =
                  false;

                // 最後の描画待ち
                await new Promise(
                  resolve =>
                    setTimeout(
                      resolve,
                      1200
                    )
                );

                await window
                  .__capturePortableNow();

                const all =
                  [
                    ...window
                      .__chatCapturePortable
                      .values()
                  ];

                const imageCount =
                  all.reduce(
                    (n, x) =>
                      n +
                      (
                        x.images
                          ?.length ||
                        0
                      ),
                    0
                  );

                const embeddedCount =
                  all
                    .flatMap(
                      x =>
                        x.images ||
                        []
                    )
                    .filter(
                      x =>
                        !!x.dataUrl
                    )
                    .length;

                console.log(
                  "🎉 全自動捕獲完了:",
                  all.length,
                  "メッセージ / 📸",
                  imageCount,
                  "画像 / 💾",
                  embeddedCount,
                  "画像本体"
                );

                console.log(
                  "💾 JSON保存：__savePortableCapture()"
                );
              }

            } catch (e) {

              console.error(
                "❌ 全自動捕獲中にエラー:",
                e
              );

              window
                .__stopAutoCapture();

            } finally {

              tickBusy = false;
            }

          },
          INTERVAL
        );
    };

  // =========================================================
  // 9. 通常監視開始
  // =========================================================

  window
    .__installUploadWatch();

  window.__chatObserver =
    new MutationObserver(
      () => {

        clearTimeout(
          window
            .__chatCaptureTimer
        );

        window
          .__chatCaptureTimer =
          setTimeout(
            () => {

              window
                .__capturePortableNow();

            },
            120
          );
      }
    );

  window
    .__chatObserver
    .observe(
      document.body,
      {
        childList:
          true,

        subtree:
          true
      }
    );

  // 起動地点を一度捕獲
  window
    .__capturePortableNow();

  console.log(
    `🪄 ChatAttic v1.1 捕獲モジュール起動 (${window.__chatAtticProvider})`
  );

  console.log(
    "🚂 全自動捕獲開始：__startAutoCapture()"
  );

  console.log(
    "🛑 緊急停止：__stopAutoCapture()"
  );

  console.log(
    "💾 JSON保存：__savePortableCapture()"
  );
})();