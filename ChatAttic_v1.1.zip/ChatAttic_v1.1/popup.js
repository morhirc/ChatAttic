const statusEl = document.getElementById("status");

function status(text, cls=""){
  statusEl.textContent = text;
  statusEl.className = "status " + cls;
}

async function getChatTab(){
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id) throw new Error("現在のタブを取得できません。");
  if(!/^https:\/\/(?:chatgpt\.com|gemini\.google\.com)\//.test(tab.url || "")){
    throw new Error("ChatGPTまたはGeminiの会話ページで実行してください。");
  }
  return tab;
}

async function injectBridge(tabId){
  // Manifest更新直後など、既存タブにcontent scriptがまだいない場合の保険。
  await chrome.scripting.executeScript({
    target:{tabId},
    files:["bridge.js"]
  });
}

async function injectCapture(tabId){
  const check = await chrome.scripting.executeScript({
    target:{tabId},
    world:"MAIN",
    func:()=>typeof window.__startAutoCapture === "function"
  });

  if(!check?.[0]?.result){
    await chrome.scripting.executeScript({
      target:{tabId},
      world:"MAIN",
      files:["capture.js"]
    });
    await new Promise(r=>setTimeout(r,250));
  }
}

async function prepare(tabId){
  await injectBridge(tabId);
  await injectCapture(tabId);
}

async function callMain(fn){
  const tab = await getChatTab();
  await prepare(tab.id);
  return chrome.scripting.executeScript({
    target:{tabId:tab.id},
    world:"MAIN",
    func:fn
  });
}

document.getElementById("saveAll").addEventListener("click", async ()=>{
  try{
    const tab = await getChatTab();
    status("捕獲の準備中…");

    await prepare(tab.id);

    const result = await chrome.scripting.executeScript({
      target:{tabId:tab.id},
      world:"MAIN",
      func:()=>{
        if (window.__chatAutoCaptureRunning) return "running";
        window.__startAutoCapture();
        return "started";
      }
    });

    if(result?.[0]?.result === "running"){
      status("すでに捕獲中です。完了後にJSON保存→アーカイブツールを開きます。","ok");
    }else{
      status("捕獲開始！ 完了後にJSON保存→アーカイブツールを開きます。","ok");
    }
  }catch(e){
    status(e.message || String(e),"bad");
  }
});

document.getElementById("stop").addEventListener("click", async ()=>{
  try{
    await callMain(()=>window.__stopAutoCapture());
    status("捕獲を停止しました。","ok");
  }catch(e){
    status(e.message || String(e),"bad");
  }
});

document.getElementById("save").addEventListener("click", async ()=>{
  try{
    await callMain(()=>window.__savePortableCapture());
    status("JSONを手動保存しました。","ok");
  }catch(e){
    status(e.message || String(e),"bad");
  }
});

document.getElementById("convert").addEventListener("click", ()=>{
  chrome.tabs.create({url:chrome.runtime.getURL("converter.html")});
});