ChatAttic v1.1
ChatGPT / Google Gemini 会話保存＆ビューア

■ v1.1 の主な変更
・Google Gemini（gemini.google.com）の表示中会話を保存できるようにしました。
・ChatGPT / Gemini をページURLから自動判定します。
・Geminiでは user-query と model-response / message-content を読み取り、共通JSON形式に変換します。
・Gemini保存時のJSON名は gemini-conversation-complete.json です。
・ビューアは保存データの provider に応じて「ChatGPT」「Gemini」を表示します。

■ インストール
1. ChatAttic_v1.1.zip を任意の場所へ解凍します。
2. Chrome / Brave で「拡張機能を管理」を開きます。
3. デベロッパーモードをオンにします。
4. 「パッケージ化されていない拡張機能を読み込む」を押します。
5. 解凍した ChatAttic_v1.1 フォルダを選択します。

■ ChatGPT / Gemini の会話を保存
1. 保存したい会話をブラウザで開きます。
2. ChatAtticアイコンを押します。
3. 「会話を保存」を押します。
4. 表示中の会話を表示位置から上方向へ自動捕獲し、JSON保存後にアーカイブツールを開きます。

■ 大量の会話を保存する場合
ChatGPT / Geminiで大量の会話を保存する場合は、一度会話の先頭までスクロールして過去のメッセージを読み込み、その後、最新の会話（下部）まで戻してから「会話を保存」を押してください。
会話量・画像数・PC環境によって、事前の読み込みや捕獲に時間がかかる場合があります。

■ 対応ページ
・https://chatgpt.com/*
・https://gemini.google.com/*

■ 注意
GeminiはWeb画面のDOM構造を利用して捕獲しています。Google側の画面構造が変更された場合、将来の更新が必要になる可能性があります。
ChatAtticは個人制作の非公式ツールです。OpenAI / Googleの公式・公認・提携製品ではありません。

■ バージョン
ChatAttic v1.1
Gemini対応初版
