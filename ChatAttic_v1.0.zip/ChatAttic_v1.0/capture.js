(() => {
  // =========================================================
  // ChatGPT会話捕獲ツール v4.1
  // 本文 + 画像 + 元アップロード画像 + 全自動巡回
  // =========================================================

  // ---------------------------------------------------------
  // 古い監視・自動運転を停止
  // ---------------------------------------------------------

  try {
    window.__chatObserver?.disconnect();
  } catch {}

  try {
    window.__chatPortableAbort?.abort();
  } catch {}

  try {
    if (window.__chatAutoScrollTimer) {
      clearInterval(window.__chatAutoScrollTimer);
    }
  } catch {}

  // ---------------------------------------------------------
  // 保存場所
  // ---------------------------------------------------------

  window.__chatCapturePortable = new Map();

  window.__chatUploadCache = new Map();

  window.__chatUploadQueue = [];

  window.__chatPortableAbort =
    new AbortController();

  window.__chatAutoCaptureRunning = false;

  window.__chatAutoScrollTimer = null;

  const signal =
    window.__chatPortableAbort.signal;

  // =========================================================
  // 1. アップロード元画像を確保
  // =========================================================

  window.__captureUploadFile =
    async (file) => {

      if (!file) {
        return;
      }

      if (
        !file.type?.startsWith("image/")
      ) {
        return;
      }

      const dataUrl =
        await new Promise(
          (resolve, reject) => {

            const reader =
              new FileReader();

            reader.onload =
              () => {
                resolve(
                  reader.result
                );
              };

            reader.onerror =
              () => {
                reject(
                  reader.error
                );
              };

            reader.readAsDataURL(
              file
            );
          }
        );

      const entry = {
        alt:
          file.name || null,

        name:
          file.name || null,

        type:
          file.type || null,

        size:
          file.size || null,

        dataUrl:
          dataUrl,

        capturedAt:
          Date.now(),

        used:
          false
      };

      if (file.name) {
        window
          .__chatUploadCache
          .set(
            file.name,
            entry
          );
      }

      window
        .__chatUploadQueue
        .push(entry);

      console.log(
        "📸 元画像を確保:",
        file.name ||
          "(名前なし)",
        file.size,
        "bytes"
      );
    };

  // =========================================================
  // 2. change / paste / drop 監視
  // =========================================================

  window.__installUploadWatch =
    () => {

      const handleFiles =
        async (
          files,
          source
        ) => {

          if (!files?.length) {
            return;
          }

          for (
            const file of files
          ) {
            await window
              .__captureUploadFile(
                file
              );
          }

          console.log(
            "🚨 元ファイル捕獲:",
            source,
            files.length,
            "件"
          );
        };

      // ファイル選択
      document.addEventListener(
        "change",
        async (e) => {

          const input =
            e.target;

          if (
            input
              instanceof
              HTMLInputElement &&
            input.type ===
              "file" &&
            input.files?.length
          ) {
            await handleFiles(
              [...input.files],
              "change"
            );
          }
        },
        {
          capture: true,
          signal: signal
        }
      );

      // クリップボード貼り付け
      document.addEventListener(
        "paste",
        async (e) => {

          if (
            e.clipboardData
              ?.files
              ?.length
          ) {
            await handleFiles(
              [
                ...e
                  .clipboardData
                  .files
              ],
              "paste"
            );
          }
        },
        {
          capture: true,
          signal: signal
        }
      );

      // ドラッグ＆ドロップ
      document.addEventListener(
        "drop",
        async (e) => {

          if (
            e.dataTransfer
              ?.files
              ?.length
          ) {
            await handleFiles(
              [
                ...e
                  .dataTransfer
                  .files
              ],
              "drop"
            );
          }
        },
        {
          capture: true,
          signal: signal
        }
      );

      console.log(
        "🚓 画像アップロード待ち伏せ開始 " +
        "(change / paste / drop)"
      );
    };

  // =========================================================
  // 3. img → 画像本体
  // =========================================================

  async function imageToDataURL(
    img
  ) {

    const src =
      img.currentSrc ||
      img.src;

    if (!src) {
      return null;
    }

    // faviconは画像として扱わない
    if (
      src.includes(
        "google.com/s2/favicons"
      )
    ) {
      return null;
    }

    // -------------------------------------------------------
    // A. ファイル名一致の元画像
    // -------------------------------------------------------

    if (img.alt) {

      const cached =
        window
          .__chatUploadCache
          .get(
            img.alt
          );

      if (
        cached?.dataUrl
      ) {

        cached.used = true;

        return {
          alt:
            img.alt ||
            cached.alt,

          src:
            src,

          width:
            img.naturalWidth ||
            null,

          height:
            img.naturalHeight ||
            null,

          type:
            cached.type,

          size:
            cached.size,

          dataUrl:
            cached.dataUrl,

          source:
            "upload-cache"
        };
      }
    }

    // -------------------------------------------------------
    // B. blob画像
    //
    // blobを後から取らず、
    // 添付時に確保済みの元画像を使う
    // -------------------------------------------------------

    if (
      src.startsWith(
        "blob:"
      )
    ) {

      const pending =
        [
          ...window
            .__chatUploadQueue
        ]
          .reverse()
          .find(
            x =>
              !x.used &&
              x.dataUrl
          );

      if (pending) {

        pending.used = true;

        return {
          alt:
            img.alt ||
            pending.alt,

          src:
            src,

          width:
            img.naturalWidth ||
            null,

          height:
            img.naturalHeight ||
            null,

          type:
            pending.type,

          size:
            pending.size,

          dataUrl:
            pending.dataUrl,

          source:
            "upload-queue"
        };
      }

      return {
        alt:
          img.alt ||
          null,

        src:
          src,

        error:
          "blob画像: 元アップロード画像を捕獲できませんでした"
      };
    }

    // -------------------------------------------------------
    // C. 通常画像
    // -------------------------------------------------------

    try {

      const res =
        await fetch(
          src,
          {
            credentials:
              "include"
          }
        );

      if (!res.ok) {
        throw new Error(
          "HTTP " +
          res.status
        );
      }

      const blob =
        await res.blob();

      const dataUrl =
        await new Promise(
          (
            resolve,
            reject
          ) => {

            const reader =
              new FileReader();

            reader.onload =
              () => {
                resolve(
                  reader.result
                );
              };

            reader.onerror =
              () => {
                reject(
                  reader.error
                );
              };

            reader
              .readAsDataURL(
                blob
              );
          }
        );

      return {
        alt:
          img.alt ||
          null,

        src:
          src,

        width:
          img.naturalWidth ||
          null,

        height:
          img.naturalHeight ||
          null,

        type:
          blob.type ||
          null,

        size:
          blob.size ||
          null,

        dataUrl:
          dataUrl,

        source:
          "fetch"
      };

    } catch (e) {

      return {
        alt:
          img.alt ||
          null,

        src:
          src,

        error:
          String(e)
      };
    }
  }

  // =========================================================
  // 4. 現在表示されている会話を捕獲
  // =========================================================

  window.__capturePortableNow =
    async () => {

      const messageElements =
        [
          ...document
            .querySelectorAll(
              "[data-message-author-role]"
            )
        ];

      for (
        const el of
        messageElements
      ) {

        const id =
          el
            .closest(
              "[data-message-id]"
            )
            ?.getAttribute(
              "data-message-id"
            );

        const turnEl =
          el.closest(
            '[data-testid^="conversation-turn-"]'
          );

        const turnText =
          turnEl
            ?.getAttribute(
              "data-testid"
            );

        const turn =
          turnText
            ? Number(
                turnText
                  .replace(
                    "conversation-turn-",
                    ""
                  )
              )
            : null;

        if (
          !id ||
          turn === null ||
          !turnEl
        ) {
          continue;
        }

        let item =
          window
            .__chatCapturePortable
            .get(id);

        if (!item) {

          item = {
            turn:
              turn,

            id:
              id,

            role:
              el
                .getAttribute(
                  "data-message-author-role"
                ),

            text:
              el.innerText,

            images:
              []
          };

          window
            .__chatCapturePortable
            .set(
              id,
              item
            );

        } else {

          item.turn =
            turn;

          item.text =
            el.innerText;
        }

        const imgs =
          [
            ...turnEl
              .querySelectorAll(
                "img"
              )
          ];

        for (
          const img of imgs
        ) {

          const src =
            img.currentSrc ||
            img.src;

          if (!src) {
            continue;
          }

          // favicon除外
          if (
            src.includes(
              "google.com/s2/favicons"
            )
          ) {
            continue;
          }

          // altなしのUI画像などを除外
          if (
            !img.alt &&
            !src.startsWith(
              "blob:"
            ) &&
            !src.includes(
              "/backend-api/estuary/"
            )
          ) {
            continue;
          }

          // 同じ画像を二重登録しない
          if (
            item.images.some(
              x =>
                x.src ===
                src
            )
          ) {
            continue;
          }

          const captured =
            await imageToDataURL(
              img
            );

          if (!captured) {
            continue;
          }

          item.images.push(
            captured
          );

          if (
            captured.dataUrl &&
            captured.source
              ?.startsWith(
                "upload"
              )
          ) {
            console.log(
              "🎯 元画像をTurnへ合流:",
              turn,
              captured.alt ||
                "(名前なし)"
            );
          }
        }
      }

      const all =
        [
          ...window
            .__chatCapturePortable
            .values()
        ];

      const imageCount =
        all.reduce(
          (n, x) =>
            n +
            (
              x.images
                ?.length ||
              0
            ),
          0
        );

      const embeddedCount =
        all
          .flatMap(
            x =>
              x.images ||
              []
          )
          .filter(
            x =>
              !!x.dataUrl
          )
          .length;

      console.log(
        "📦 捕獲:",
        all.length,
        "メッセージ / 📸",
        imageCount,
        "画像 / 💾",
        embeddedCount,
        "画像本体"
      );
    };

  // =========================================================
  // 5. JSON保存
  // =========================================================

  window.__savePortableCapture =
    () => {

      const complete =
        [
          ...window
            .__chatCapturePortable
            .values()
        ]
          .sort(
            (a, b) =>
              a.turn -
              b.turn
          );

      const blob =
        new Blob(
          [
            JSON.stringify(
              complete,
              null,
              2
            )
          ],
          {
            type:
              "application/json"
          }
        );

      const a =
        document
          .createElement(
            "a"
          );

      a.href =
        URL.createObjectURL(
          blob
        );

      a.download =
        "chatgpt-conversation-complete.json";

      document.body
        .appendChild(a);

      a.click();

      a.remove();

      setTimeout(
        () => {
          URL
            .revokeObjectURL(
              a.href
            );
        },
        5000
      );

      console.log(
        "💾 保存しました:",
        complete.length,
        "メッセージ"
      );
    };

  // =========================================================
  // 6. ChatGPTのスクロール担当を自動検出
  // =========================================================

  window.__findChatScroller =
    () => {

      const candidates =
        [
          ...document
            .querySelectorAll(
              "*"
            )
        ]
          .filter(
            el => {

              const s =
                getComputedStyle(
                  el
                );

              return (
                el.scrollHeight >
                  el.clientHeight +
                  100 &&
                (
                  s.overflowY ===
                    "auto" ||
                  s.overflowY ===
                    "scroll"
                )
              );
            }
          )
          .sort(
            (a, b) =>
              (
                b.scrollHeight -
                b.clientHeight
              ) -
              (
                a.scrollHeight -
                a.clientHeight
              )
          );

      return (
        candidates[0] ||
        null
      );
    };

  // =========================================================
  // 7. 全自動捕獲停止
  // =========================================================

  window.__stopAutoCapture =
    () => {

      if (
        window
          .__chatAutoScrollTimer
      ) {

        clearInterval(
          window
            .__chatAutoScrollTimer
        );

        window
          .__chatAutoScrollTimer =
          null;
      }

      window
        .__chatAutoCaptureRunning =
        false;

      console.log(
        "🛑 全自動捕獲を手動停止"
      );
    };

  // =========================================================
  // 8. 全自動捕獲開始
  //
  // 下 → 上 → 下
  // 自動巡回しながら捕獲
  // =========================================================

  window.__startAutoCapture =
    async () => {

      if (
        window
          .__chatAutoCaptureRunning
      ) {

        console.log(
          "⚠️ 全自動捕獲はすでに動作中です"
        );

        return;
      }

      const scroller =
        window
          .__findChatScroller();

      if (!scroller) {

        console.error(
          "❌ ChatGPTのスクロール領域を発見できません"
        );

        return;
      }

      window
        .__chatAutoCaptureRunning =
        true;

      window
        .__chatAutoScroller =
        scroller;

      // -1 = 上
      //  1 = 下
      let direction = -1;

      let lastTop =
        scroller.scrollTop;

      let stuckCount = 0;

      let tickBusy = false;

      // 実験で成功した速度
      const STEP = 700;

      const INTERVAL = 500;

      // 端で8回動かなければ到着判定
      const EDGE_TICKS = 8;

      console.log(
        "🚂 全自動捕獲開始：上へ出発",
        "scrollTop:",
        Math.round(
          scroller.scrollTop
        )
      );

      // 出発地点を捕獲
      await window
        .__capturePortableNow();

      window
        .__chatAutoScrollTimer =
        setInterval(
          async () => {

            if (
              tickBusy ||
              !window
                .__chatAutoCaptureRunning
            ) {
              return;
            }

            tickBusy = true;

            try {

              scroller.scrollBy({
                top:
                  direction *
                  STEP,

                behavior:
                  "auto"
              });

              // DOM差し替え待ち
              await new Promise(
                resolve =>
                  setTimeout(
                    resolve,
                    180
                  )
              );

              // 新しく見えたTurnを捕獲
              await window
                .__capturePortableNow();

              const now =
                scroller.scrollTop;

              if (
                Math.abs(
                  now -
                  lastTop
                ) < 5
              ) {
                stuckCount++;
              } else {
                stuckCount = 0;
              }

              lastTop = now;

              // -----------------------------------------------
              // 上端
              // -----------------------------------------------

if (
  direction === -1 &&
  stuckCount >= EDGE_TICKS
) {
  clearInterval(
    window.__chatAutoScrollTimer
  );

  window.__chatAutoScrollTimer =
    null;

  window.__chatAutoCaptureRunning =
    false;

  console.log(
    "🏔️ 上端到着：片道運転終了"
  );

  // 上端の描画を待って最終捕獲
  await new Promise(
    resolve =>
      setTimeout(
        resolve,
        1200
      )
  );

  await window
    .__capturePortableNow();

  const all =
    [
      ...window
        .__chatCapturePortable
        .values()
    ];

  const imageCount =
    all.reduce(
      (n, x) =>
        n +
        (
          x.images?.length ||
          0
        ),
      0
    );

  const embeddedCount =
    all
      .flatMap(
        x =>
          x.images ||
          []
      )
      .filter(
        x =>
          !!x.dataUrl
      )
      .length;

  console.log(
    "🎉 v4.1 片道捕獲完了:",
    all.length,
    "メッセージ / 📸",
    imageCount,
    "画像 / 💾",
    embeddedCount,
    "画像本体"
  );

  console.log(
    "💾 JSON保存：__savePortableCapture()"
  );

  // v1.6:
  // 捕獲が完了した「このページ自身」のコンテキストでJSON保存を実行する。
  // 拡張のService Workerから保存関数を呼び戻す往復をやめ、安定性を上げる。
  let autoSaveOk = false;
  let autoSaveError = null;

  try {
    if (typeof window.__savePortableCapture === "function") {
      window.__savePortableCapture();
      autoSaveOk = true;
      console.log("✅ v1.6 JSON自動保存を実行");
    } else {
      throw new Error("__savePortableCapture が見つかりません");
    }
  } catch (e) {
    autoSaveError = String(e?.message || e);
    console.error("❌ v1.6 JSON自動保存失敗:", e);
  }

  // ダウンロード開始を少し待ってから、常駐content scriptへ完了通知。
  setTimeout(() => {
    window.postMessage({
      source: "CHATGPT_CONVERSATION_ARCHIVER",
      type: "CAPTURE_COMPLETE",
      detail: {
        messages: all.length,
        images: imageCount,
        embedded: embeddedCount,
        completedAt: Date.now(),
        autoSaveOk,
        autoSaveError
      }
    }, "*");
  }, 500);

  return;
}
              // -----------------------------------------------
              // 下端
              // -----------------------------------------------

              if (
                direction === 1 &&
                stuckCount >=
                  EDGE_TICKS
              ) {

                clearInterval(
                  window
                    .__chatAutoScrollTimer
                );

                window
                  .__chatAutoScrollTimer =
                  null;

                window
                  .__chatAutoCaptureRunning =
                  false;

                // 最後の描画待ち
                await new Promise(
                  resolve =>
                    setTimeout(
                      resolve,
                      1200
                    )
                );

                await window
                  .__capturePortableNow();

                const all =
                  [
                    ...window
                      .__chatCapturePortable
                      .values()
                  ];

                const imageCount =
                  all.reduce(
                    (n, x) =>
                      n +
                      (
                        x.images
                          ?.length ||
                        0
                      ),
                    0
                  );

                const embeddedCount =
                  all
                    .flatMap(
                      x =>
                        x.images ||
                        []
                    )
                    .filter(
                      x =>
                        !!x.dataUrl
                    )
                    .length;

                console.log(
                  "🎉 全自動捕獲完了:",
                  all.length,
                  "メッセージ / 📸",
                  imageCount,
                  "画像 / 💾",
                  embeddedCount,
                  "画像本体"
                );

                console.log(
                  "💾 JSON保存：__savePortableCapture()"
                );
              }

            } catch (e) {

              console.error(
                "❌ 全自動捕獲中にエラー:",
                e
              );

              window
                .__stopAutoCapture();

            } finally {

              tickBusy = false;
            }

          },
          INTERVAL
        );
    };

  // =========================================================
  // 9. 通常監視開始
  // =========================================================

  window
    .__installUploadWatch();

  window.__chatObserver =
    new MutationObserver(
      () => {

        clearTimeout(
          window
            .__chatCaptureTimer
        );

        window
          .__chatCaptureTimer =
          setTimeout(
            () => {

              window
                .__capturePortableNow();

            },
            120
          );
      }
    );

  window
    .__chatObserver
    .observe(
      document.body,
      {
        childList:
          true,

        subtree:
          true
      }
    );

  // 起動地点を一度捕獲
  window
    .__capturePortableNow();

  console.log(
    "🪄 ChatGPT会話捕獲ツール v4.1 起動"
  );

  console.log(
    "🚂 全自動捕獲開始：__startAutoCapture()"
  );

  console.log(
    "🛑 緊急停止：__stopAutoCapture()"
  );

  console.log(
    "💾 JSON保存：__savePortableCapture()"
  );
})();