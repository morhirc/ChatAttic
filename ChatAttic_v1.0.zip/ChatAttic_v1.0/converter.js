let conversation = null;
let inputName = "";
let archiveTitle = "ChatAttic";
let exportZipContext = null;

const $ = id => document.getElementById(id);
const drop = $("drop");
const fileInput = $("file");
const makeBtn = $("make");
const resetBtn = $("reset");
const status = $("status");

function esc(s){
  return String(s ?? "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#39;");
}

function renderText(text){
  text = String(text ?? "");
  const re = /```([\s\S]*?)```/g;
  let out = "";
  let last = 0;
  let m;

  while ((m = re.exec(text)) !== null){
    const normal = text.slice(last, m.index);
    if (normal){
      out += '<div class="prose">' + esc(normal).replaceAll("\n","<br>") + "</div>";
    }

    let code = m[1];
    code = code.replace(/^[A-Za-z0-9_+\-#.]+\s*\n/, "");
    out += "<pre><code>" + esc(code.trim()) + "</code></pre>";
    last = re.lastIndex;
  }

  const rest = text.slice(last);
  if (rest){
    out += '<div class="prose">' + esc(rest).replaceAll("\n","<br>") + "</div>";
  }

  return out || '<div class="prose empty">（本文なし）</div>';
}

function normalizeData(raw){
  if (Array.isArray(raw)) return raw;

  if (raw && typeof raw === "object"){
    for (const k of ["messages","conversation","items"]){
      if (Array.isArray(raw[k])) return raw[k];
    }
  }

  throw new Error("会話配列を見つけられませんでした。捕獲ツールのJSONか確認してください。");
}



function bytesToText(bytes){
  return new TextDecoder("utf-8").decode(bytes);
}

function mimeFromBytes(bytes, fallbackName=""){
  if(bytes.length >= 8 && bytes[0]===0x89 && bytes[1]===0x50 && bytes[2]===0x4e && bytes[3]===0x47) return "image/png";
  if(bytes.length >= 3 && bytes[0]===0xff && bytes[1]===0xd8 && bytes[2]===0xff) return "image/jpeg";
  if(bytes.length >= 6 && bytes[0]===0x47 && bytes[1]===0x49 && bytes[2]===0x46) return "image/gif";
  if(bytes.length >= 12 && bytes[0]===0x52 && bytes[1]===0x49 && bytes[2]===0x46 && bytes[8]===0x57 && bytes[9]===0x45 && bytes[10]===0x42 && bytes[11]===0x50) return "image/webp";
  if(bytes.length >= 4 && bytes[0]===0x25 && bytes[1]===0x50 && bytes[2]===0x44 && bytes[3]===0x46) return "application/pdf";
  const n = fallbackName.toLowerCase();
  if(n.endsWith(".png")) return "image/png";
  if(n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
  if(n.endsWith(".gif")) return "image/gif";
  if(n.endsWith(".webp")) return "image/webp";
  return "application/octet-stream";
}

function bytesToDataUrl(bytes, mime){
  let binary = "";
  const chunk = 0x8000;
  for(let i=0;i<bytes.length;i+=chunk){
    binary += String.fromCharCode(...bytes.subarray(i, i+chunk));
  }
  return `data:${mime};base64,${btoa(binary)}`;
}

async function inflateRaw(bytes){
  if(typeof DecompressionStream !== "function"){
    throw new Error("このブラウザはZIP展開機能に対応していません。Brave / Chromeを更新してください。");
  }
  const ds = new DecompressionStream("deflate-raw");
  const stream = new Blob([bytes]).stream().pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

const MAX_ZIP_FILE_BYTES = 1024 * 1024 * 1024;      // 1 GB: ZIP本体
const MAX_ZIP_ENTRY_BYTES = 256 * 1024 * 1024;      // 256 MB: 1ファイル展開後
const MAX_ZIP_TOTAL_BYTES = 2 * 1024 * 1024 * 1024; // 2 GB: ZIP内の展開後合計

class SimpleZipReader{
  constructor(buffer){
    this.buffer = buffer;
    this.bytes = new Uint8Array(buffer);
    this.view = new DataView(buffer);
    this.entries = new Map();
    this._parse();
  }
  _u16(o){ return this.view.getUint16(o,true); }
  _u32(o){ return this.view.getUint32(o,true); }
  _parse(){
    let eocd = -1;
    const min = Math.max(0, this.bytes.length - 65557);
    for(let i=this.bytes.length-22;i>=min;i--){
      if(this._u32(i)===0x06054b50){ eocd=i; break; }
    }
    if(eocd < 0) throw new Error("ZIPの終端情報を見つけられませんでした。");
    const total = this._u16(eocd+10);
    let pos = this._u32(eocd+16);
    for(let i=0;i<total;i++){
      if(this._u32(pos)!==0x02014b50) throw new Error("ZIPのファイル一覧を読み取れませんでした。");
      const method = this._u16(pos+10);
      const compSize = this._u32(pos+20);
      const uncompSize = this._u32(pos+24);
      const nameLen = this._u16(pos+28);
      const extraLen = this._u16(pos+30);
      const commentLen = this._u16(pos+32);
      const localOffset = this._u32(pos+42);
      const name = bytesToText(this.bytes.subarray(pos+46,pos+46+nameLen));
      if(uncompSize > MAX_ZIP_ENTRY_BYTES){
        throw new Error(`ZIP内のファイルが大きすぎます：${name}（展開後 ${(uncompSize/1024/1024).toFixed(1)} MB）`);
      }
      this.entries.set(name,{name,method,compSize,uncompSize,localOffset});
      pos += 46 + nameLen + extraLen + commentLen;
    }
    const totalUncompressed = [...this.entries.values()].reduce((n,e)=>n + e.uncompSize, 0);
    if(totalUncompressed > MAX_ZIP_TOTAL_BYTES){
      throw new Error(`ZIPの展開後合計サイズが大きすぎます（約 ${(totalUncompressed/1024/1024/1024).toFixed(2)} GB）。安全のため読み込みを中止しました。`);
    }
  }
  names(){ return [...this.entries.keys()]; }
  findByBase(base){
    return this.names().find(n=>n===base || n.endsWith("/"+base));
  }
  async read(name){
    const e=this.entries.get(name);
    if(!e) throw new Error(`ZIP内に ${name} がありません。`);
    const p=e.localOffset;
    if(this._u32(p)!==0x04034b50) throw new Error("ZIPのローカルヘッダーが壊れています。");
    const nameLen=this._u16(p+26), extraLen=this._u16(p+28);
    const start=p+30+nameLen+extraLen;
    const comp=this.bytes.subarray(start,start+e.compSize);
    if(e.method===0){
      if(comp.length > MAX_ZIP_ENTRY_BYTES) throw new Error("ZIP内のファイルが大きすぎます。");
      return comp.slice();
    }
    if(e.method===8){
      const result = await inflateRaw(comp);
      if(result.length > MAX_ZIP_ENTRY_BYTES) throw new Error("ZIP展開後のファイルが大きすぎます。");
      return result;
    }
    throw new Error(`未対応のZIP圧縮方式です (${e.method})。`);
  }
  async readText(name){ return bytesToText(await this.read(name)); }
}

function sanitizeExportText(text){
  return String(text ?? "")
    .replace(/\ue200(?:cite|turn|search|open|fetch|news|image|file|map)?\ue201?/g, "")
    .replace(/\ue200[^\ue201]*\ue201/g, "")
    .trim();
}

function exportConversationPath(conv){
  const mapping = conv?.mapping || {};
  let id = conv?.current_node;
  const path = [];
  const seen = new Set();
  while(id && mapping[id] && !seen.has(id)){
    seen.add(id);
    path.push(mapping[id]);
    id = mapping[id]?.parent;
  }
  path.reverse();
  return path;
}

function summarizeExportConversation(conv){
  let count=0, images=0;
  for(const node of exportConversationPath(conv)){
    const m=node?.message;
    const role=m?.author?.role;
    const c=m?.content || {};
    if(!m || !["user","assistant"].includes(role)) continue;
    if(!["text","multimodal_text"].includes(c.content_type)) continue;
    const parts=Array.isArray(c.parts)?c.parts:[];
    const hasText=parts.some(p=>typeof p==="string" && p.trim());
    const imgs=parts.filter(p=>p && typeof p==="object" && p.content_type==="image_asset_pointer");
    if(hasText || imgs.length){ count++; images += imgs.length; }
  }
  return {count,images};
}

async function convertOpenAIConversation(conv, zip){
  const out=[];
  let turn=0;
  for(const node of exportConversationPath(conv)){
    const m=node?.message;
    const role=m?.author?.role;
    const c=m?.content || {};
    if(!m || !["user","assistant"].includes(role)) continue;
    if(!["text","multimodal_text"].includes(c.content_type)) continue;
    const parts=Array.isArray(c.parts)?c.parts:[];
    const text=sanitizeExportText(parts.filter(p=>typeof p==="string").join("\n"));
    const imageParts=parts.filter(p=>p && typeof p==="object" && p.content_type==="image_asset_pointer");
    if(!text && !imageParts.length) continue;
    turn++;
    const images=[];
    for(const part of imageParts){
      const pointer=String(part.asset_pointer || "");
      const id=pointer.split("//").pop();
      const base=id ? id + ".dat" : "";
      const entryName=base ? zip.findByBase(base) : null;
      if(!entryName){
        images.push({alt:"画像", dataUrl:null});
        continue;
      }
      try{
        const bytes=await zip.read(entryName);
        const mime=mimeFromBytes(bytes,entryName);
        if(mime.startsWith("image/")){
          images.push({alt:"画像",dataUrl:bytesToDataUrl(bytes,mime)});
        }else{
          images.push({alt:"添付ファイル",dataUrl:null});
        }
      }catch{
        images.push({alt:"画像",dataUrl:null});
      }
    }
    out.push({
      role,text,turn,images,
      create_time: m?.create_time || null
    });
  }
  return out;
}

function exportSearchText(conv){
  const bits=[conv?.title || ""];
  for(const node of exportConversationPath(conv)){
    const m=node?.message, c=m?.content || {};
    if(!m || !["user","assistant"].includes(m?.author?.role)) continue;
    const parts=Array.isArray(c.parts)?c.parts:[];
    for(const p of parts) if(typeof p==="string") bits.push(p);
  }
  return bits.join("\n").normalize("NFKC").toLowerCase();
}

function renderExportList(conversations){
  const panel=$("exportPanel");
  const select=$("exportConversation");
  const info=$("exportInfo");
  const search=$("exportSearch");
  const searchInfo=$("exportSearchInfo");
  const rows=conversations
    .map((conv,index)=>({conv,index,summary:summarizeExportConversation(conv),search:exportSearchText(conv)}))
    .sort((a,b)=>(b.conv.update_time||0)-(a.conv.update_time||0));

  function paint(){
    const q=(search?.value || "").normalize("NFKC").trim().toLowerCase();
    select.replaceChildren();
    let shown=0;
    for(const {conv,index,summary,search:text} of rows){
      if(q && !text.includes(q)) continue;
      shown++;
      const opt=document.createElement("option");
      opt.value=String(index);
      const date=conv.update_time ? new Date(conv.update_time*1000).toLocaleString("ja-JP") : "日時不明";
      opt.textContent=`${conv.title || "無題の会話"}  (${summary.count}件 / 画像${summary.images} / ${date})`;
      select.appendChild(opt);
    }
    if(searchInfo) searchInfo.textContent=q ? `${shown} / ${rows.length} 会話` : `${rows.length} 会話`;
    $("exportView").disabled=shown===0;
    $("exportMake").disabled=shown===0;
    $("exportJson").disabled=shown===0;
  }
  if(search){
    search.value="";
    search.oninput=paint;
  }
  paint();
  panel.hidden=false;
  info.textContent=`OpenAIエクスポートを読み込みました：${conversations.length}会話。検索して、そのまま閲覧できます。`;
}

async function loadOpenAIExportZip(file){
  status.className="status";
  status.textContent="OpenAIエクスポートZIPを読み込み中…";
  if(file.size > MAX_ZIP_FILE_BYTES){
    throw new Error(`ZIPファイルが大きすぎます（約 ${(file.size/1024/1024).toFixed(0)} MB）。安全のため1GBを超えるZIPは読み込みません。`);
  }
  const buffer=await file.arrayBuffer();
  const zip=new SimpleZipReader(buffer);
  const convNames=zip.names().filter(n=>/(^|\/)conversations(?:-\d+)?\.json$/i.test(n));
  if(!convNames.length){
    throw new Error("OpenAIエクスポートの conversations.json を見つけられませんでした。");
  }
  let conversations=[];
  for(const name of convNames){
    const raw=JSON.parse(await zip.readText(name));
    if(Array.isArray(raw)) conversations.push(...raw);
  }
  if(!conversations.length) throw new Error("ZIP内に会話データがありませんでした。");
  exportZipContext={zip,conversations,fileName:file.name};
  conversation=null;
  inputName=file.name;
  makeBtn.disabled=true;
  resetBtn.disabled=false;
  renderExportList(conversations);
  $("mCount").textContent=conversations.reduce((n,c)=>n+summarizeExportConversation(c).count,0);
  $("iCount").textContent=conversations.reduce((n,c)=>n+summarizeExportConversation(c).images,0);
  $("okCount").textContent="選択後";
  $("ngCount").textContent="選択後";
  status.className="status ok";
  status.textContent=`読み込み成功：${conversations.length}会話。下の一覧から選んでください。`;
}

function analyze(data){
  let images = 0;
  let embedded = 0;

  for (const m of data){
    const arr = Array.isArray(m.images) ? m.images : [];
    for (const img of arr){
      images++;
      const d = img?.dataUrl || img?.dataURL || img?.data;
      if (typeof d === "string" && d.startsWith("data:image")) embedded++;
    }
  }

  $("mCount").textContent = data.length;
  $("iCount").textContent = images;
  $("okCount").textContent = embedded;
  $("ngCount").textContent = images - embedded;

  return {images, embedded};
}

function fileKind(file){
  const name = String(file?.name || "").toLowerCase();
  if (name.endsWith(".json")) return "json";
  if (name.endsWith(".html") || name.endsWith(".htm")) return "html";
  if (name.endsWith(".zip")) return "zip";
  return "other";
}

function downloadViewer(){
  if (!conversation) return false;

  status.className = "status";
  status.textContent = "ChatGPT風HTMLを生成中…";

  const viewer = buildViewer(conversation);
  const blob = new Blob([viewer], {type:"text/html;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");

  a.href = url;
  a.download = safeBaseName(inputName) + "_閲覧版.html";
  document.body.appendChild(a);
  a.click();
  a.remove();

  setTimeout(()=>URL.revokeObjectURL(url), 10000);

  status.className = "status ok";
  status.textContent = "ChatGPT風の閲覧HTMLを保存しました。";
  return true;
}

async function openHtmlFile(file){
  status.className = "status";
  status.textContent = "会話アーカイブを開いています…";

  const text = await file.text();
  if (!/<!doctype\s+html|<html[\s>]/i.test(text)) {
    throw new Error("HTMLファイルとして認識できませんでした。");
  }

  // 保存HTMLを直接blobタブで開くと、拡張機能CSPの影響で
  // HTML内のインラインJavaScript（検索など）が止まることがある。
  // v1.10では専用viewer.htmlがHTMLを読み込み、
  // 検索・Turn移動・画像拡大などをviewer.js側で付け直す。
  const blob = new Blob([text], {type:"text/html;charset=utf-8"});
  const blobUrl = URL.createObjectURL(blob);
  const viewerUrl =
    chrome.runtime.getURL("viewer.html") +
    "?src=" + encodeURIComponent(blobUrl);

  const opened = window.open(viewerUrl, "_blank");
  if (!opened) {
    const a = document.createElement("a");
    a.href = viewerUrl;
    a.target = "_blank";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  // viewer側は即fetchする。十分な猶予を置いて解放。
  setTimeout(()=>URL.revokeObjectURL(blobUrl), 120000);

  status.className = "status ok";
  status.textContent = "会話アーカイブを新しいタブで開きました。";
}

async function loadJsonFile(file, autoOpen=true){
  status.className = "status";
  status.textContent = "JSONを読み込み中…";

  const text = await file.text();
  const raw = JSON.parse(text);
  conversation = normalizeData(raw);
  inputName = file.name || "chatgpt-conversation-complete.json";
  const s = analyze(conversation);

  makeBtn.disabled = false;
  resetBtn.disabled = false;
  status.className = "status ok";
  status.textContent =
    `読み込み成功：${conversation.length}メッセージ / ${s.images}画像 / 画像本体あり ${s.embedded}件`;

  if (autoOpen) {
    await new Promise(r=>setTimeout(r,50));
    await openGeneratedViewer();
    status.className = "status ok";
    status.textContent += " 新しいタブでそのまま開きました。必要な時だけ「閲覧HTMLを保存」を使えます。";
  }
}

async function handleFile(file, {autoOpenJson=true} = {}){
  try{
    const kind = fileKind(file);

    if (kind === "json") {
      await loadJsonFile(file, autoOpenJson);
      return;
    }

    if (kind === "html") {
      await openHtmlFile(file);
      return;
    }

    if (kind === "zip") {
      await loadOpenAIExportZip(file);
      return;
    }

    status.className = "status bad";
    status.textContent = "OpenAI ZIP / JSON / HTML ファイルを選んでください。";
  }catch(e){
    if (fileKind(file) === "json") {
      conversation = null;
      makeBtn.disabled = true;
    }
    resetBtn.disabled = false;
    status.className = "status bad";
    status.textContent = "処理失敗：" + (e?.message || String(e));
  }
}

drop.addEventListener("click", ()=>fileInput.click());
fileInput.addEventListener("change", ()=>{
  if (fileInput.files?.[0]) handleFile(fileInput.files[0], {autoOpenJson:true});
});

["dragenter","dragover"].forEach(type=>{
  drop.addEventListener(type,e=>{
    e.preventDefault();
    drop.classList.add("drag");
  });
});

["dragleave","drop"].forEach(type=>{
  drop.addEventListener(type,e=>{
    e.preventDefault();
    drop.classList.remove("drag");
  });
});

// Brave / Chrome の「ファイルをそのまま開く」既定動作を完全に止める。
// dragover は常に preventDefault しないと drop イベント自体がアプリ側へ来ないブラウザがある。
["dragenter","dragover","drop"].forEach(type=>{
  window.addEventListener(type, e=>{
    e.preventDefault();
    e.stopPropagation();
  }, {capture:true});
});

window.addEventListener("dragenter", e=>{
  drop.classList.add("drag");
}, {capture:true});

window.addEventListener("dragover", e=>{
  if (e.dataTransfer) e.dataTransfer.dropEffect = "copy";
  drop.classList.add("drag");
}, {capture:true});

window.addEventListener("dragleave", e=>{
  if (!e.relatedTarget) drop.classList.remove("drag");
}, {capture:true});

window.addEventListener("drop", e=>{
  drop.classList.remove("drag");
  const files = e.dataTransfer ? [...e.dataTransfer.files] : [];
  const f = files[0];

  if (!f) {
    status.className = "status bad";
    status.textContent = "ファイルを受け取れませんでした。クリックして選択してください。";
    return;
  }

  handleFile(f, {autoOpenJson:true});
}, {capture:true});

resetBtn.addEventListener("click", ()=>{
  conversation = null;
  inputName = "";
  archiveTitle = "ChatAttic";
  exportZipContext = null;
  $("exportPanel").hidden = true;
  fileInput.value = "";
  ["mCount","iCount","okCount","ngCount"].forEach(id=>$(id).textContent="-");
  makeBtn.disabled = true;
  resetBtn.disabled = true;
  status.className = "status";
  status.textContent = "OpenAI ZIP / JSON / HTML をドロップまたは選択してください。";
});

function buildViewer(data){
  let imgTotal = 0;
  let imgOK = 0;
  const messages = [];

  data.forEach((m, idx)=>{
    const role = m.role || "";
    const label = role === "user" ? "あなた" : (role === "assistant" ? "ChatGPT" : role);
    const turn = m.turn ?? (idx + 1);
    const rawTime = Number(m.create_time || m.timestamp || 0);
    const dateObj = rawTime ? new Date(rawTime * (rawTime < 100000000000 ? 1000 : 1)) : null;
    const dateKey = dateObj
      ? `${dateObj.getFullYear()}-${String(dateObj.getMonth()+1).padStart(2,"0")}-${String(dateObj.getDate()).padStart(2,"0")}`
      : "";
    const dateLabel = dateObj ? dateObj.toLocaleString("ja-JP") : "";
    const imageBlocks = [];

    const imgs = Array.isArray(m.images) ? m.images : [];
    imgs.forEach((img, j)=>{
      imgTotal++;
      const altRaw = img?.alt || `画像 ${j+1}`;
      const alt = esc(altRaw);
      const d = img?.dataUrl || img?.dataURL || img?.data;

      if (typeof d === "string" && d.startsWith("data:image")){
        imgOK++;
        imageBlocks.push(
          `<figure class="shot"><img src="${d}" alt="${alt}" loading="lazy"><figcaption>${alt}</figcaption></figure>`
        );
      }else{
        imageBlocks.push(`<div class="missing">［画像未復元: ${alt}］</div>`);
      }
    });

    const avatar = role === "assistant" ? "GPT" : "YOU";
    messages.push(
      `<article class="msg ${esc(role)}" data-turn="${esc(turn)}" data-role="${esc(role)}" data-date="${esc(dateKey)}">` +
      `<header><span class="avatar">${avatar}</span><span class="role">${esc(label)}</span>${dateLabel ? `<span class="msgdate">${esc(dateLabel)}</span>` : ""}<span class="turn">Turn ${esc(turn)}</span></header>` +
      `<div class="content">` +
      renderText(m.text || "") +
      imageBlocks.join("") +
      `</div></article>`
    );
  });

  const css = `
:root{
  --bg:#ffffff;--panel:#ffffff;--text:#0d0d0d;--muted:#6b6b6b;--line:#e8e8e8;
  --userbubble:#f4f4f4;--control:#f7f7f7;--control-hover:#ececec;--code:#0d0d0d;
  --codeText:#f7f7f7;--accent:#10a37f;--highlight:#fff4bf;--shadow:0 8px 30px rgba(0,0,0,.12)
}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI","Yu Gothic UI","Yu Gothic","Meiryo",sans-serif;background:var(--bg);color:var(--text);font-size:15px}
.topbar{position:sticky;top:0;z-index:30;background:rgba(255,255,255,.94);backdrop-filter:blur(12px);border-bottom:1px solid var(--line)}
.toolbar{max-width:1280px;margin:auto;display:flex;gap:8px;align-items:center;padding:10px 16px;flex-wrap:wrap}
.title{font-weight:650;font-size:16px;white-space:nowrap;margin-right:auto}.title small{color:var(--muted);font-weight:500;margin-left:8px}
.searchcluster{display:flex;align-items:center;gap:6px;flex:0 0 auto}.searchwrap{position:relative;display:flex;align-items:center}.search,.turninput{height:38px;padding:0 12px;border:1px solid #d9d9d9;border-radius:10px;background:#fff;color:var(--text);outline:none}
.search{width:min(350px,38vw);padding-right:34px}.searchclear{position:absolute;right:5px;width:28px;height:28px;border:0;background:transparent;border-radius:50%;cursor:pointer;font-size:18px;color:var(--muted);display:none}.searchclear.show{display:block}.searchclear:hover{background:var(--control-hover)}.turninput{width:88px}.search:focus,.turninput:focus{border-color:#aaa;box-shadow:0 0 0 2px rgba(0,0,0,.04)}
.btn{height:38px;border:0;background:var(--control);padding:0 12px;border-radius:10px;cursor:pointer;white-space:nowrap;color:var(--text);font-weight:550}.btn:hover{background:var(--control-hover)}.btn.active{background:#e8e8e8}.datepanel{display:none;align-items:center;gap:6px}.datepanel.open{display:flex}.dateinput{height:38px;border:1px solid #d9d9d9;border-radius:10px;padding:0 8px;background:#fff}.msgdate{color:var(--muted);font-size:11px}
.meta{max-width:760px;margin:0 auto;padding:14px 22px 4px;color:var(--muted);font-size:12px;display:flex;gap:14px;flex-wrap:wrap}
.wrap{max-width:760px;margin:0 auto;padding:4px 22px 70px}
.msg{position:relative;scroll-margin-top:92px;padding:18px 0 22px;min-height:56px}
.msg+ .msg{border-top:0}
.msg header{display:flex;align-items:center;gap:8px;margin-bottom:9px;font-size:14px}
.avatar{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:12px;font-weight:750;flex:0 0 26px}
.user .avatar{background:#ececec;color:#333}.assistant .avatar{background:#111;color:white}.role{font-weight:650}.turn{color:#9a9a9a;font-size:11px;margin-left:auto;opacity:.7}
.content{min-width:0}.prose{line-height:1.78;overflow-wrap:anywhere;white-space:normal}.prose+.prose{margin-top:12px}.empty{color:var(--muted);font-style:italic}
.msg.user{display:flex;flex-direction:column;align-items:flex-end}.msg.user header{width:min(88%,680px);justify-content:flex-end}.msg.user header .turn{order:-1;margin-left:0;margin-right:auto}.msg.user .content{width:min(88%,680px);background:var(--userbubble);border-radius:18px;padding:11px 15px}.msg.user .prose{line-height:1.65}
.msg.assistant .content{width:100%}
pre{position:relative;background:var(--code);color:var(--codeText);padding:15px 16px;border-radius:12px;overflow:auto;white-space:pre-wrap;line-height:1.6;margin:13px 0}pre code{background:transparent;color:inherit;padding:0}
code{font-family:"Cascadia Code",Consolas,"Noto Sans Mono CJK JP",monospace;font-size:13px}
.shot{margin:14px 0 4px}.shot img{display:block;max-width:min(100%,620px);max-height:520px;width:auto;height:auto;border-radius:14px;border:1px solid var(--line);cursor:zoom-in;background:#fff}.user .shot{margin-left:auto}.user .shot img{margin-left:auto}
figcaption{font-size:11px;color:var(--muted);margin-top:5px}.user figcaption{text-align:right}.missing{padding:10px 12px;border:1px dashed #ccc;border-radius:10px;color:#777;background:#fafafa;margin-top:8px}
.hidden{display:none!important}.highlight{animation:flash 2.2s ease}.searchmark{background:#ffe58f;border-radius:3px;padding:0 1px}.searchmark.current{outline:2px solid #d79b00;background:#ffd54f}.searchcount,.turnstatus{font-size:12px;color:var(--muted);white-space:nowrap}
.searchnav{height:38px;display:flex;align-items:center;gap:2px;background:var(--control);border-radius:10px;padding:0 3px}
.navbtn{width:30px;height:30px;border:0;border-radius:8px;background:transparent;cursor:pointer;color:var(--text);font-size:22px;line-height:1}.navbtn:hover{background:var(--control-hover)}
.searchnav .searchcount{min-width:42px;text-align:center}.searchcount.idle{opacity:.38}@keyframes flash{0%,100%{background:transparent}20%,65%{background:var(--highlight)}}
#lightbox{position:fixed;inset:0;z-index:60;background:rgba(0,0,0,.9);display:none;align-items:center;justify-content:center;padding:18px}#lightbox.open{display:flex}
#lightbox img{max-width:94vw;max-height:88vh;object-fit:contain;box-shadow:var(--shadow);cursor:zoom-out}.lbnav{position:fixed;top:50%;transform:translateY(-50%);border:0;background:rgba(255,255,255,.14);color:#fff;font-size:34px;width:52px;height:72px;border-radius:12px;cursor:pointer}
#prev{left:16px}#next{right:16px}#lbcap{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);color:#fff;background:rgba(0,0,0,.55);padding:7px 10px;border-radius:8px;font-size:13px;max-width:80vw;text-align:center}
.hint{position:fixed;bottom:12px;right:12px;background:rgba(0,0,0,.72);color:#fff;padding:7px 9px;border-radius:8px;font-size:12px;opacity:.7}
@media(max-width:900px){.toolbar{align-items:stretch}.title{width:100%;margin-bottom:2px}.searchcluster{width:100%;order:2}.searchwrap{flex:1}.search{width:100%}.btn,.turninput{order:3}.meta{padding-left:16px;padding-right:16px}.wrap{padding-left:16px;padding-right:16px}}
@media(max-width:620px){body{font-size:14px}.toolbar{gap:6px}.btn{padding:0 9px}.msg{padding:14px 0 18px}.msg.user header,.msg.user .content{width:94%}.msg.user .content{border-radius:16px}.hint{display:none}.lbnav{width:42px;height:60px;font-size:28px}.turn{display:none}}
`;

  const js = `
const search=document.getElementById('search');
const clear=document.getElementById('clear');
const dateToggle=document.getElementById('dateToggle');
const datePanel=document.getElementById('datePanel');
const dateFrom=document.getElementById('dateFrom');
const dateTo=document.getElementById('dateTo');
const dateClear=document.getElementById('dateClear');
const msgs=[...document.querySelectorAll('.msg')];
const resultCount=document.getElementById('resultCount');
const searchPrev=document.getElementById('searchPrev');
const searchNext=document.getElementById('searchNext');
const searchCount=document.getElementById('searchCount');
const turnStatus=document.getElementById('turnStatus');
const buttons={all:document.getElementById('showAll'),user:document.getElementById('showUser'),assistant:document.getElementById('showAssistant')};

let roleFilter='all';
let marks=[];
let currentMark=-1;

function normalize(s){
  return String(s??'').normalize('NFKC').toLocaleLowerCase('ja');
}

function updateButtons(){
  Object.entries(buttons).forEach(([k,b])=>b?.classList.toggle('active',k===roleFilter));
}

function clearMarks(){
  document.querySelectorAll('.searchmark').forEach(mark=>{
    const parent=mark.parentNode;
    parent.replaceChild(document.createTextNode(mark.textContent),mark);
    parent.normalize();
  });
  marks=[];
  currentMark=-1;
}

function markText(root,query){
  if(!query)return;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{
    acceptNode(node){
      if(!node.nodeValue.trim())return NodeFilter.FILTER_REJECT;
      if(node.parentElement?.closest('script,style,pre,code,header'))return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });

  const nodes=[];
  while(walker.nextNode())nodes.push(walker.currentNode);

  const qNorm=normalize(query);

  nodes.forEach(node=>{
    const raw=node.nodeValue;
    const norm=normalize(raw);
    let from=0;
    let found=false;
    const parts=[];

    while(true){
      const idx=norm.indexOf(qNorm,from);
      if(idx<0)break;
      found=true;
      if(idx>from)parts.push(document.createTextNode(raw.slice(from,idx)));

      const mark=document.createElement('mark');
      mark.className='searchmark';
      mark.textContent=raw.slice(idx,idx+query.length);
      parts.push(mark);
      from=idx+query.length;
    }

    if(found){
      if(from<raw.length)parts.push(document.createTextNode(raw.slice(from)));
      const frag=document.createDocumentFragment();
      parts.forEach(p=>frag.appendChild(p));
      node.parentNode.replaceChild(frag,node);
    }
  });
}

function refreshMarks(){
  marks=[...document.querySelectorAll('.searchmark')].filter(m=>!m.closest('.hidden'));

  if(!marks.length){
    currentMark=-1;
    if(searchCount){
      searchCount.textContent='0 / 0';
      searchCount.classList.toggle('idle', !search?.value.trim());
    }
    return;
  }

  if(currentMark<0||currentMark>=marks.length)currentMark=0;
  marks.forEach((m,i)=>m.classList.toggle('current',i===currentMark));
  if(searchCount){
    searchCount.textContent=(currentMark+1)+' / '+marks.length;
    searchCount.classList.remove('idle');
  }
}

function gotoMark(delta){
  if(!marks.length)return;
  currentMark=(currentMark+delta+marks.length)%marks.length;
  marks.forEach((m,i)=>m.classList.toggle('current',i===currentMark));
  if(searchCount){
    searchCount.textContent=(currentMark+1)+' / '+marks.length;
    searchCount.classList.remove('idle');
  }
  marks[currentMark].scrollIntoView({behavior:'smooth',block:'center'});
}

function applyFilters(){
  const q=search.value.trim();
  let visible=0;

  clearMarks();

  msgs.forEach(m=>{
    const roleOk=roleFilter==='all'||m.dataset.role===roleFilter;
    const textOk=!q||normalize(m.innerText).includes(normalize(q));
    const d=m.dataset.date||'';
    const dateOk=(!dateFrom?.value || (d && d>=dateFrom.value)) && (!dateTo?.value || (d && d<=dateTo.value));
    const show=roleOk&&textOk&&dateOk;
    m.classList.toggle('hidden',!show);
    if(show)visible++;
  });

  if(resultCount)resultCount.textContent='表示 '+visible+'件';

  if(q){
    msgs.filter(m=>!m.classList.contains('hidden')).forEach(m=>markText(m,q));
  }

  refreshMarks();
}

search.addEventListener('input',applyFilters);

clear.addEventListener('click',()=>{
  search.value='';
  applyFilters();
  search.focus();
});

searchPrev.addEventListener('click',()=>gotoMark(-1));
searchNext.addEventListener('click',()=>gotoMark(1));

search.addEventListener('keydown',e=>{
  if(e.key==='Enter'){
    e.preventDefault();
    gotoMark(e.shiftKey?-1:1);
  }
});

buttons.all.addEventListener('click',()=>{roleFilter='all';updateButtons();applyFilters();});
buttons.user.addEventListener('click',()=>{roleFilter='user';updateButtons();applyFilters();});
buttons.assistant.addEventListener('click',()=>{roleFilter='assistant';updateButtons();applyFilters();});

document.getElementById('top').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
document.getElementById('bottom').addEventListener('click',()=>window.scrollTo({top:document.documentElement.scrollHeight,behavior:'smooth'}));

document.getElementById('jumpTurn').addEventListener('click',()=>{
  const n=document.getElementById('turnInput').value.trim();
  if(!n)return;
  msgs.forEach(m=>m.classList.remove('highlight'));
  const target=msgs.find(m=>m.dataset.turn===n);
  if(target){
    target.classList.remove('hidden');
    target.classList.add('highlight');
    target.scrollIntoView({behavior:'smooth',block:'start'});
    setTimeout(()=>target.classList.remove('highlight'),2200);
  }else{
    alert('Turn '+n+' は見つかりませんでした');
  }
});

document.getElementById('turnInput').addEventListener('keydown',e=>{
  if(e.key==='Enter')document.getElementById('jumpTurn').click();
});

const allTurns=msgs.map(m=>Number(m.dataset.turn)).filter(Number.isFinite);
const maxTurn=allTurns.length?Math.max(...allTurns):msgs.length;

function updateTurnStatus(){
  if(!turnStatus)return;

  let current=null;
  const y=window.scrollY+110;

  for(const m of msgs){
    if(m.offsetTop<=y)current=m;
    else break;
  }

  const turn=current?.dataset.turn||(msgs[0]?.dataset.turn??'-');
  turnStatus.textContent='Turn '+turn+' / '+maxTurn;
}

window.addEventListener('scroll',updateTurnStatus,{passive:true});
window.addEventListener('resize',updateTurnStatus);

const lb=document.getElementById('lightbox');
const lbImg=lb.querySelector('img');
const lbCap=document.getElementById('lbcap');
const galleryImgs=[...document.querySelectorAll('.shot img')];
let currentIndex=-1;

function openAt(i){
  if(!galleryImgs.length)return;
  currentIndex=(i+galleryImgs.length)%galleryImgs.length;
  const img=galleryImgs[currentIndex];
  lbImg.src=img.src;
  lbImg.alt=img.alt;
  const turn=img.closest('.msg')?.dataset.turn||'';
  lbCap.textContent='Turn '+turn+' / '+(img.alt||'画像')+' / '+(currentIndex+1)+' of '+galleryImgs.length;
  lb.classList.add('open');
  lb.setAttribute('aria-hidden','false');
}

galleryImgs.forEach((img,i)=>img.addEventListener('click',e=>{
  e.stopPropagation();
  openAt(i);
}));

function closeLB(){
  lb.classList.remove('open');
  lb.setAttribute('aria-hidden','true');
  lbImg.src='';
}

document.getElementById('prev').addEventListener('click',e=>{e.stopPropagation();openAt(currentIndex-1);});
document.getElementById('next').addEventListener('click',e=>{e.stopPropagation();openAt(currentIndex+1);});
lb.addEventListener('click',closeLB);

document.addEventListener('keydown',e=>{
  if(!lb.classList.contains('open'))return;
  if(e.key==='Escape')closeLB();
  if(e.key==='ArrowLeft')openAt(currentIndex-1);
  if(e.key==='ArrowRight')openAt(currentIndex+1);
});

updateButtons();
applyFilters();
updateTurnStatus();
`;

  return `<!doctype html>
<html lang="ja">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ChatGPTビューア</title>
<style>${css}</style>
</head>
<body>
<div class="topbar"><div class="toolbar">
<div class="title">${esc(archiveTitle)}</div>
<div class="searchcluster">
<div class="searchwrap"><input id="search" class="search" placeholder="会話を検索…"><button class="searchclear" id="clear" title="検索をクリア" aria-label="検索をクリア">×</button></div>
<div class="searchnav" title="検索結果を移動"><button class="navbtn" id="searchPrev" title="前の検索結果（Shift+Enter）" aria-label="前の検索結果">‹</button><span id="searchCount" class="searchcount idle">0 / 0</span><button class="navbtn" id="searchNext" title="次の検索結果（Enter）" aria-label="次の検索結果">›</button></div>
</div>
<button class="btn" id="dateToggle">📅 日付</button>
<div class="datepanel" id="datePanel"><input id="dateFrom" class="dateinput" type="date" title="開始日"><span>～</span><input id="dateTo" class="dateinput" type="date" title="終了日"><button class="btn" id="dateClear">解除</button></div>
<button class="btn active" id="showAll">全部</button>
<button class="btn" id="showUser">あなた</button>
<button class="btn" id="showAssistant">ChatGPT</button>
<input id="turnInput" class="turninput" type="number" placeholder="Turn">
<button class="btn" id="jumpTurn">Turnへ</button>
<span id="turnStatus" class="turnstatus">Turn - / -</span>
<button class="btn" id="top">↑ 先頭</button>
<button class="btn" id="bottom">↓ 最後</button>
</div></div>
<div class="meta">
<span>メッセージ ${data.length}件</span>
<span>画像記録 ${imgTotal}件</span>
<span>復元画像 ${imgOK}件</span>
<span>未復元 ${imgTotal-imgOK}件</span>
<span id="resultCount">表示 ${data.length}件</span>
</div>
<main class="wrap">${messages.join("")}</main>
<div id="lightbox" aria-hidden="true">
<button class="lbnav" id="prev" aria-label="前の画像">‹</button>
<img alt="">
<button class="lbnav" id="next" aria-label="次の画像">›</button>
<div id="lbcap"></div>
</div>
<div class="hint">画像クリックで拡大 / ← → で画像送り / Escで閉じる</div>
<script>${js}<\/script>
</body>
</html>`;
}

function safeBaseName(name){
  return (name || "chatgpt-conversation")
    .replace(/\.(json|zip)$/i,"")
    .replace(/[\\/:*?"<>|]+/g,"_");
}


async function prepareExportConversation(){
  if(!exportZipContext) throw new Error("OpenAI ZIPを先に読み込んでください。");
  const idx=Number($("exportConversation").value);
  const conv=exportZipContext.conversations[idx];
  if(!conv) throw new Error("会話を選択してください。");
  status.className="status";
  status.textContent="選択した会話を変換中… 画像が多い場合は少し処理が続きます。";
  conversation=await convertOpenAIConversation(conv, exportZipContext.zip);
  archiveTitle=conv.title || "ChatAttic";
  inputName=archiveTitle + ".json";
  const an=analyze(conversation);
  makeBtn.disabled=false;
  status.className="status ok";
  status.textContent=`変換成功：${conversation.length}メッセージ / ${an.images}画像。`;
  return {conv,an};
}

async function openGeneratedViewer(){
  const html=buildViewer(conversation);
  const blob=new Blob([html],{type:"text/html;charset=utf-8"});
  const blobUrl=URL.createObjectURL(blob);
  const viewerUrl=chrome.runtime.getURL("viewer.html")+"?src="+encodeURIComponent(blobUrl);
  const opened=window.open(viewerUrl,"_blank");
  if(!opened){
    const a=document.createElement("a"); a.href=viewerUrl; a.target="_blank"; a.rel="noopener";
    document.body.appendChild(a); a.click(); a.remove();
  }
  setTimeout(()=>URL.revokeObjectURL(blobUrl),120000);
}

$("exportView").addEventListener("click", async ()=>{
  try{
    await prepareExportConversation();
    await openGeneratedViewer();
    status.textContent += " 新しいタブで開きました。";
  }catch(e){ status.className="status bad"; status.textContent="表示失敗："+(e?.message||String(e)); }
});

$("exportMake").addEventListener("click", async ()=>{
  try{
    await prepareExportConversation();
    downloadViewer();
    status.textContent += " HTMLを保存しました。";
  }catch(e){ status.className="status bad"; status.textContent="保存失敗："+(e?.message||String(e)); }
});

$("exportJson").addEventListener("click", async ()=>{
  try{
    const {conv}=await prepareExportConversation();
    const blob=new Blob([JSON.stringify(conv,null,2)],{type:"application/json;charset=utf-8"});
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url; a.download=safeBaseName(conv.title || "chatgpt-conversation")+".json";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    status.textContent += " 元会話JSONを保存しました。";
  }catch(e){ status.className="status bad"; status.textContent="JSON保存失敗："+(e?.message||String(e)); }
});

makeBtn.addEventListener("click", ()=>{
  try{
    downloadViewer();
  }catch(e){
    status.className = "status bad";
    status.textContent = "変換失敗：" + (e?.message || String(e));
  }
});

// v1.9 完了表示
(() => {
  const params = new URLSearchParams(location.search);

  if (params.get("done") === "1") {
    const saved = params.get("saved") === "1";
    status.className = saved ? "status ok" : "status bad";
    status.textContent = saved
      ? "✅ 捕獲完了。JSON自動保存を実行しました。"
      : "⚠️ 捕獲は完了しましたが、JSON自動保存で問題がありました。";
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "archive-capture-complete") return;

    const saved = !!message?.detail?.autoSaveOk;
    status.className = saved ? "status ok" : "status bad";
    status.textContent = saved
      ? "✅ 捕獲完了！ JSON自動保存を実行しました。"
      : "⚠️ 捕獲完了。ただしJSON自動保存で問題がありました。非常用の「JSONだけ保存」を使ってください。";

    try {
      const clean = new URL(location.href);
      clean.searchParams.delete("waiting");
      clean.searchParams.set("done","1");
      clean.searchParams.set("saved", saved ? "1" : "0");
      history.replaceState(null, "", clean.toString());
    } catch {}
  });
})();

