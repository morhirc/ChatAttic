const handledCompletions = new Set();

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "capture-complete-v16") return;

  const completedAt = Number(message?.detail?.completedAt || 0);
  const tabId = Number(sender?.tab?.id || 0);
  const key = `${tabId}:${completedAt}`;

  // bridge重複や再送があっても、同じ捕獲完了では1回しか開かない
  if (handledCompletions.has(key)) return;
  handledCompletions.add(key);

  // メモリが増え続けないよう少し後で削除
  setTimeout(() => handledCompletions.delete(key), 120000);

  (async () => {
    try {
      // JSON保存処理はcapture.js側で先に実行済み。
      // 保存開始後にアーカイブツールを1回だけ開く。
      await new Promise(resolve => setTimeout(resolve, 700));

      const url = new URL(chrome.runtime.getURL("converter.html"));
      url.searchParams.set("done", "1");
      url.searchParams.set(
        "saved",
        message?.detail?.autoSaveOk ? "1" : "0"
      );

      await chrome.tabs.create({
        url: url.toString(),
        active: true
      });
    } catch (e) {
      console.error("ChatGPT会話保存 v1.9 完了処理エラー:", e);
    }
  })();
});